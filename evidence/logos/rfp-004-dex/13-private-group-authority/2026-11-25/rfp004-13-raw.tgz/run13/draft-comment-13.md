## RFP-004 private and group-authority flows: runtime results (lez-programs@1cfaa5e)

**Summary.** All 36 private, group-authority and fresh-account integration tests for the token and AMM programs pass, in dev mode and with real proofs. This includes the two AMM cases that failed with `CircuitProvingError("rx len failed")` or hung in the [M1 re-review](https://github.com/logos-co/rfp/issues/217#issuecomment-6361006722). When we stop the prover in the middle of a proof, the test fails with the same `rx len failed` error, and the next run passes. So the old error most likely came from a prover process that died, not from the programs. The private path in the SDK and app is still missing (DEX-16 to DEX-19 in #9), so 7 client cases are Blocked. One private-swap case has no test.

With real proving, each private case takes 3 to 7 minutes and up to about 9.2 GiB of memory on a 12-vCPU CPU machine. Dev mode does not create proofs, so dev-mode results alone do not show that private flows work.

| Item | Value |
|---|---|
| Repository | [`logos-blockchain/lez-programs@1cfaa5e`](https://github.com/logos-blockchain/lez-programs/tree/1cfaa5e3446a684e6e9b61cfb243038dae6465ea) |
| LEZ | `v0.2.5-rc2` (`d8596eb734bf9c9ce801afb92df06098a2eb098a`), from `Cargo.lock` |
| RISC Zero | `risc0-zkvm` 3.0.5, `r0vm` 3.0.5, local CPU prover (`RISC0_PROVER=ipc`), no Bonsai |
| Machine | Linux 6.8 x86-64, 12 vCPU, 17 GiB RAM, 15 GiB swap |
| Date | 2026-11-25 |


## Counts

| Pass | Fail | Blocked | Not run | Total |
|---:|---:|---:|---:|---:|
| 38 | 0 | 7 | 2 | 47 |

## Results

Dev = `RISC0_DEV_MODE=1` (no proof). Real = `RISC0_DEV_MODE` unset, local CPU proving. Peak RSS is the largest `r0vm` process. Proofs = number of `r0vm` sessions that proved.

| # | Case | Area | Requirement | What it checks | Dev | Real | Peak RSS | Proofs | Status |
|---:|---|---|---|---|---|---|---:|---:|---|
| 1 | [`token_transfer_fresh_public_recipient_is_unauthenticated_since_v0_2_5`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L319) | Fresh account | Privacy.4 (boundary) | Transfer to a fresh public account succeeds with no recipient signature (LEZ v0.2.5 regression marker) | Pass · 0.4 s | Pass · 0.3 s | 0.02 GiB | 0 | Pass |
| 2 | [`token_transfer_fresh_authorized_public_recipient`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L350) | Fresh account | Privacy.4 (boundary) | Transfer to a fresh public account that signs | Pass · 0.3 s | Pass · 0.3 s | 0.02 GiB | 0 | Pass |
| 3 | [`token_mint_fresh_public_recipient_is_unauthenticated_since_v0_2_5`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L510) | Fresh account | Privacy.4 (boundary) | Mint to a fresh public account succeeds with no recipient signature (regression marker) | Pass · 0.3 s | Pass · 0.3 s | 0.02 GiB | 0 | Pass |
| 4 | [`token_mint_fresh_authorized_public_recipient`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L540) | Fresh account | Privacy.4 (boundary) | Mint to a fresh public account that signs | Pass · 0.3 s | Pass · 0.3 s | 0.02 GiB | 0 | Pass |
| 5 | [`token_shielded_transfer`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L681) | Shield | F.1, F.4 | Public → new private holding (shield), recipient key not needed | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 6 | [`token_shielded_transfer_authorized_private_init`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L709) | Shield | F.1, F.4 | Public → new private holding, recipient authorizes with its key | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 7 | [`token_private_transfer`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L737) | Private | F.1 | Private → private transfer | Pass · 1.2 s | Pass · 7 min 17 s | 9.16 GiB | 4 | Pass |
| 8 | [`token_deshielded_transfer`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L817) | Deshield | F.1, F.4 | Private → public transfer (deshield) | Pass · 1.2 s | Pass · 5 min 59 s | 9.16 GiB | 4 | Pass |
| 9 | [`token_mint_private_unauthorized`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L891) | Private holding | — | Mint into a new private holding without recipient key | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 10 | [`token_mint_authorized_private_init`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L952) | Private holding | — | Mint into a new private holding with recipient key | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 11 | [`token_mint_into_existing_private_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1017) | Private holding | — | Mint into an existing private holding | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 12 | [`token_private_burn`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1098) | Private holding | — | Burn from a private holding | Pass · 0.6 s | Pass · 2 min 58 s | 9.16 GiB | 2 | Pass |
| 13 | [`token_transfer_into_existing_private_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1178) | Shield | F.1, F.4 | Public → existing private holding (re-shield) | Pass · 0.7 s | Pass · 3 min 02 s | 9.16 GiB | 2 | Pass |
| 14 | [`token_private_transfer_into_existing_private_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1249) | Private | F.1 | Private → existing private holding | Pass · 0.7 s | Pass · 4 min 19 s | 9.16 GiB | 2 | Pass |
| 15 | [`token_initialize_private_account_succeeds_for_canonical_definition`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1349) | Private holding | — | Owner initializes its own private holding | Pass · 0.8 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 16 | [`token_initialize_private_account_via_foreign_init_is_refused`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1394) | Rejection | — | Initialize a private holding for someone else is refused | Pass · 0.6 s | Pass · 0.6 s | 0.02 GiB | 0 | Pass |
| 17 | [`token_new_fungible_definition_private_initial_holder`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1426) | Private holding | — | New token with a private initial holder | Pass · 0.7 s | Pass · 3 min 04 s | 9.16 GiB | 2 | Pass |
| 18 | [`token_new_fungible_definition_foreign_init_holder_is_refused`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1494) | Rejection | — | New token with a foreign-init initial holder is refused | Pass · 0.6 s | Pass · 0.7 s | 0.02 GiB | 0 | Pass |
| 19 | [`token_group_owned_holding_shared_control_burn`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1531) | Group authority | — | Second group member burns from a shared private holding | Pass · 1.1 s | Pass · 5 min 58 s | 9.16 GiB | 4 | Pass |
| 20 | [`token_group_owned_holding_shared_control_transfer`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1639) | Group authority | — | Second group member transfers from a shared private holding | Pass · 0.7 s | Pass · 4 min 19 s | 9.16 GiB | 2 | Pass |
| 21 | [`token_group_owned_holding_shared_control_initialize`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L1716) | Group authority | — | Group member initializes a shared private holding | Pass · 0.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 22 | [`token_mint_with_authority_to_private_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/token.rs#L2070) | Private holding | — | Mint authority mints into a private holding | Pass · 0.8 s | Pass · 3 min 04 s | 9.16 GiB | 2 | Pass |
| 23 | [`amm_initialize_private_namespace_owner`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5422) | Historical M1 | — | Private account owns an AMM namespace (failed or hung at 071375c) | Pass · 1.7 s | Pass · 2 min 59 s | 9.16 GiB | 2 | Pass |
| 24 | [`amm_update_config_group_owned_admin_authority`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5494) | Historical M1 | — | Group-owned admin rotates AMM config (failed or hung at 071375c) | Pass · 1.7 s | Pass · 3 min 00 s | 9.16 GiB | 2 | Pass |
| 25 | [`amm_withdraw_protocol_fees_group_owned_admin_authority`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5626) | Group authority | — | Group-owned admin withdraws protocol fees | Pass · 2.9 s | Pass · 3 min 43 s | 9.16 GiB | 3 | Pass |
| 26 | [`amm_withdraw_protocol_fees_to_private_destination`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5540) | Private | — | Protocol fees withdrawn into an existing private holding | Pass · 2.7 s | Pass · 3 min 43 s | 9.16 GiB | 3 | Pass |
| 27 | [`amm_swap_a_to_b_private_user_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L3982) | Private swap | F.4 | Exact-input swap paid from a private holding, output to a public holding | Pass · 2.5 s | Pass · 5 min 02 s | 9.16 GiB | 5 | Pass |
| 28 | [`amm_swap_a_to_b_private_unauthorized_destination_is_not_expressible`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4131) | Rejection | F.4, Privacy.3 | Swap output to a new private holding (foreign init) is refused | Pass · 2.3 s | Pass · 2.3 s | 0.02 GiB | 0 | Pass |
| 29 | [`amm_swap_a_to_b_private_authorized_init_destination_is_not_expressible`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4226) | Rejection | F.4, Privacy.3 | Swap output to a new private holding (owner init) is refused | Pass · 2.2 s | Pass · 2.3 s | 0.02 GiB | 0 | Pass |
| 30 | [`amm_swap_exact_output_private_user_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4318) | Private swap | F.4 | Exact-output swap paid from a private holding | Pass · 2.5 s | Pass · 5 min 01 s | 9.16 GiB | 5 | Pass |
| 31 | [`amm_add_liquidity_private_lp_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4488) | Private liquidity | F.3 | Add liquidity, LP tokens to a private holding | Pass · 2.6 s | Pass · 5 min 23 s | 9.16 GiB | 6 | Pass |
| 32 | [`amm_add_liquidity_private_user_holdings`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4903) | Private liquidity | F.3 | Add liquidity paid from two private holdings | Pass · 2.6 s | Pass · 7 min 02 s | 9.17 GiB | 6 | Pass |
| 33 | [`amm_remove_liquidity_private_lp_holding`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4648) | Private liquidity | F.3 | Remove liquidity, LP tokens burned from a private holding | Pass · 2.6 s | Pass · 5 min 11 s | 9.16 GiB | 6 | Pass |
| 34 | [`amm_remove_liquidity_private_new_user_holdings_is_not_expressible`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L4800) | Rejection | F.3 | Remove liquidity into new private holdings is refused | Pass · 2.1 s | Pass · 2.2 s | 0.02 GiB | 0 | Pass |
| 35 | [`amm_new_definition_private_initial_lp_holder`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5095) | Private liquidity | F.3 | Pool creation mints first LP tokens to a private holding | Pass · 2.6 s | Pass · 5 min 43 s | 9.16 GiB | 7 | Pass |
| 36 | [`amm_new_definition_foreign_init_lp_holder_is_refused`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L5264) | Rejection | F.3 | Pool creation to a foreign-init LP holder is refused | Pass · 2.2 s | Pass · 2.3 s | 0.02 GiB | 0 | Pass |
| 37 | Interrupt: stop the prover 60 s into the circuit proof of `token_mint_private_unauthorized` | Recovery | Reliability | see [Recovery](#recovery) | — | exit=101 · 1 min 06 s | — | — | Pass |
| 38 | Recovery: rerun the same case right after the interrupt | Recovery | Reliability | see [Recovery](#recovery) | — | exit=0 · 2 min 59 s | — | — | Pass |
| 39 | SDK/app: deshield → swap → re-shield from a private account | Client | F.1, F.4, U.1, Privacy.1 | No private path in SDK/app (DEX-16, #9) | — | — | — | — | Blocked |
| 40 | SDK/app: add or remove liquidity from a private account | Client | F.3 | No private path in SDK/app (DEX-16, #9) | — | — | — | — | Blocked |
| 41 | SDK/app: balance covers amount and fee in one deshield; clear error if not | Client | U.8 | No private path in SDK/app (DEX-16, #9) | — | — | — | — | Blocked |
| 42 | App: pre-confirmation summary of what is public and private | Client | Privacy.2 | No private path in SDK/app (DEX-17, #9) | — | — | — | — | Blocked |
| 43 | SDK: reject a re-shield target that is not a private account | Client | Privacy.3 | No private path in SDK/app (DEX-18, #9) | — | — | — | — | Blocked |
| 44 | SDK: fresh ephemeral public account for every private operation | Client | Privacy.4 | No private path in SDK/app (DEX-19, #9) | — | — | — | — | Blocked |
| 45 | Interrupted private flow in the SDK/app leaves no funds in the ephemeral account | Client | U.8, Privacy.1 | No private path in SDK/app (DEX-16, #9) | — | — | — | — | Blocked |
| 46 | Swap whose output goes straight into an existing private holding (re-shield in the same transaction) | Gap | F.4 | No test exists at this revision; the two new-holding variants are refused (rows above). | — | — | — | — | Not run |
| 47 | Same private/group cases at `071375c` (the M1 re-review revision) | Gap | — | Not rebuilt: disk had 5.4 GB free. See finding 1. | — | — | — | — | Not run |

## Findings

### QA13-01: The old `rx len failed` error comes from a prover that stops

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Retired at `1cfaa5e` | Epic: historical proving failures | rows 23, 24, 37, 38 |

The two AMM cases that failed or hung at `071375c` pass with real proofs here (rows 23 and 24). When we stop `r0vm` 60 s into a proof, the test fails with the same `CircuitProvingError("rx len failed")`. The error does not say that the prover stopped, so users and testers cannot act on it; the SDK should report a clear error when this happens.

<a id="recovery"></a>
<details>
<summary>Recovery test: commands and raw output</summary>

Script: `interrupt.sh`. It runs `token_mint_private_unauthorized` with real proving. It waits until the second `r0vm` session (the circuit proof) starts, waits 60 s more, then sends `SIGTERM` to that `r0vm`. Then it runs the same case again.

```text
2026-11-25T02:41:06+00:00 START interrupted
 763534  763529      60 8902832 .../v3.0.5-cargo-risczero-x86_64-unknown-linux-gnu/r0vm --port 35703
2026-11-25T02:42:12+00:00 kill -TERM r0vm pid=763534
2026-11-25T02:42:12+00:00 END interrupted exit=101 wall=66.332607347s
r0vm left after interrupted: 0
thread 'token_mint_private_unauthorized' (763458) panicked at programs/integration_tests/tests/token.rs:915:6:
called `Result::unwrap()` on an `Err` value: CircuitProvingError("rx len failed")
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 32 filtered out; finished in 66.33s

2026-11-25T02:42:14+00:00 START rerun
2026-11-25T02:45:13+00:00 END rerun exit=0 wall=178.599307629s
r0vm left after rerun: 0
test token_mint_private_unauthorized ... ok
test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 32 filtered out; finished in 178.59s
```

The stopped `r0vm` had 8.9 GB resident memory at that moment. No `r0vm` process was left after either run. The tests keep chain state in memory, so this shows that the prover recovers. It does not show recovery of funds on a real chain; that needs the SDK path (row 45).

</details>

<details>
<summary>Why we think the M1 failures were environmental</summary>

- `071375c` and `1cfaa5e` use the same LEZ tag (`v0.2.5-rc2`) and the same `risc0-zkvm` (`=3.0.5`) in `Cargo.toml`.
- The M1 re-review ran in dev mode in a sandbox. Here dev mode passes all 36 cases too.
- A stopped prover gives exactly the M1 error. A prover that is out of memory (about 9.2 GiB needed) is one likely cause. This is an inference: we did not rebuild `071375c` (row 47).

</details>

### QA13-02: Clients still cannot run private operations

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| High | Blocked | F.1, F.3, F.4, U.1, U.8, Privacy.1–4 | rows 39–45; #9 DEX-16 to DEX-19 |

The programs accept private inputs, but the SDK and app only send public operations. Users cannot run deshield → swap → re-shield, and no client checks fees, return accounts or fresh ephemeral accounts. Add the private client path; then these 7 rows can run.

### QA13-03: No test pays a private swap into a private holding

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Medium | Not run (gap) | F.4, Privacy.3 | rows 27–30, 46 |

The private swap tests pay from a private holding into a public holding. A swap into a new private holding is refused, because the AMM requires the output holding to exist already (rows 28 and 29). Add a test where the output goes into an existing private holding, and decide whether a new private holding must work.

### QA13-04: Fresh public accounts accept tokens without a signature

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Pass (documents known behavior) | Privacy.4 (boundary) | rows 1, 3 |

Since LEZ v0.2.5, anyone can transfer or mint tokens into a fresh public account without its consent; the repository marks these tests as regression markers. So a "fresh" ephemeral account can receive history from someone else before it is used. The SDK work for Privacy.4 should check this.

### QA13-05: Real proving is slow and needs a lot of memory

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Measured | Performance (the RFP sets no proving target) | Results table |

26 of the 36 cases create real proofs. Each takes 2 min 58 s to 7 min 17 s and up to 9.17 GiB (largest `r0vm`). The whole real suite took 1 h 48 min; the dev suite took 48 s.

<details>
<summary>What stays public in a private transaction</summary>

From LEZ `d8596eb`: [`privacy_preserving_transaction/message.rs:22-31`](https://github.com/logos-blockchain/logos-execution-zone/blob/d8596eb734bf9c9ce801afb92df06098a2eb098a/lee/state_machine/src/privacy_preserving_transaction/message.rs#L22-L31) and [`core/src/circuit_io.rs:171-180`](https://github.com/logos-blockchain/logos-execution-zone/blob/d8596eb734bf9c9ce801afb92df06098a2eb098a/lee/state_machine/core/src/circuit_io.rs#L171-L180).

- **Public:** every public account the call touches, with its id and full new state (`public_actions`). In a private swap this is the config, pool, both vaults, the output holding, the tick and clock accounts and the fee holding. Vault changes show trade size and direction.
- **Public:** nonces of public signers, validity windows, program image claims.
- **Per private account:** a nullifier, the commitment root, a new commitment and the encrypted new state. The private account id and balance are not in clear text.
- In `amm_swap_a_to_b_private_user_holding` the output goes to a public holding, so the recipient is public.
- We checked this by reading code. We did not test whether nullifiers or commitments can link two operations by the same user.

</details>

<details>
<summary>Commands</summary>

```bash
# environment (environment.sh)
export HOME=/home/qa/work/proving-home CARGO_HOME=/home/qa/work/cargo RUSTUP_HOME=/home/qa/work/rustup
export CARGO_TARGET_DIR=/home/qa/work/target CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=4

# build once (build.sh): 12 min 10 s, 0.57 GiB peak
RISC0_DEV_MODE=1 cargo test --locked -p integration_tests --test amm --test token --no-run --message-format=json-render-diagnostics

# each case, one at a time (run-cases.sh dev|real)
export RISC0_PROVER=ipc RISC0_EXECUTOR=ipc RISC0_SERVER_PATH=run13/r0vm-timed.sh   # wraps r0vm in /usr/bin/time -v
export RISC0_DEV_MODE=1          # dev only; unset for real
/usr/bin/time -v -o <case>/test.time timeout --kill-after=30 1800 \
  target/debug/deps/<amm|token>-<hash> --exact <case> --nocapture --test-threads=1
```

</details>

<details>
<summary>How to reproduce</summary>

- Source: `lez-programs` `1cfaa5e3446a684e6e9b61cfb243038dae6465ea`, LEZ `v0.2.5-rc2` (`d8596eb`).
- Toolchain: Rust 1.94.0 (`rust-toolchain.toml`); `rzup` install, then `r0vm` and `cargo-risczero` 3.0.5 pinned from `Cargo.lock` (as in `.github/actions/install-risc0`); guest Rust 1.97.0, guest C++ 2024.1.5.
- Image: none (host install under one work folder, about 11.6 GB).
- Scripts in `rfp004-13-scripts.tgz`: `bootstrap.sh` → `build.sh` → `orchestrate.sh` (runs `run-cases.sh dev`, `run-cases.sh real`, `interrupt.sh`), then `make_report.py` writes this comment.
- Case list: `cases.txt` (36 cases), labels in `cases-meta.tsv`.
- Run on a newer commit: change the commit in the checkout, rerun all scripts, compare the Results table.
- Devin prompt: "Run RFP-004 private-flow tests with real proving: do the work of iftech/qa-audits#13 at logos-blockchain/lez-programs@<sha> with real (non-dev-mode) RISC0 proving; Pass / Fail / Blocked / Not run per case, timings, memory, commands and raw output."

</details>

<details>
<summary>Raw output</summary>

All logs are in `rfp004-13-raw.tgz`: `build.log`, `build-cargo.jsonl`, `dev-suite.log`, `real-suite.log`, `interrupt.log`, and per case `dev|real/<case>/test.log`, `test.time` and one `r0vm.*.log` per prover session. Example (`real/amm_swap_a_to_b_private_user_holding/test.log`):

```text
running 1 test
test amm_swap_a_to_b_private_user_holding ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 55 filtered out; finished in 302.20s
```

</details>

<details>
<summary>Limits</summary>

- These are program-level integration tests with in-memory chain state, not a sequencer or devnet.
- Only the token and AMM suites are in scope. The ATA and stablecoin group-owned tests were not run.
- One run per case; times can change with machine load.
- `071375c` was not rebuilt, so the cause of the M1 failures is an inference (QA13-01).

</details>

<details>
<summary>Glossary</summary>

- **Dev mode:** `RISC0_DEV_MODE=1`. The zkVM runs the program but makes a fake proof.
- **Real proving:** a real RISC Zero proof made on this CPU.
- **Shield / deshield:** move tokens from a public account into a private holding / from a private holding to a public account.
- **Foreign init:** create a private holding for someone else, using only their public keys.
- **Group-owned:** an account controlled by a group key that several members hold.
- **Ephemeral account:** a new temporary public account for one private operation.

</details>

## Decisions for the spec owner

1. Is the private client path (DEX-16 to DEX-19) due in milestone 1, or in a later milestone?
2. Must a private swap pay into a new private holding in one transaction, or is an existing holding the intended design?
3. Is 3 to 7 minutes and about 9.2 GiB per private operation on a CPU acceptable, or should the RFP set a proving target?


# RFP-004: Privacy-Preserving Decentralized Exchange (DEX)

| Item | Link |
| --- | --- |
| Code | [`logos-blockchain/lez-programs@1cfaa5e3446a684e6e9b61cfb243038dae6465ea`](https://github.com/logos-blockchain/lez-programs/tree/1cfaa5e3446a684e6e9b61cfb243038dae6465ea) |
| Specification | [RFP-004 @ `a4323366516228875b61c72d12acb59b3d46cab7`](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#hard-requirements) |
| Tracking | [Parent #2](https://github.com/iftech/qa-audits/issues/2) · [Ecosystem #183][l1] |
| Milestones | [Accepted proposal #40](https://github.com/logos-co/rfp/issues/40) · [Milestone 1 re-review](https://github.com/logos-co/rfp/issues/217#issuecomment-6361006722) · [Milestone 2 #218](https://github.com/logos-co/rfp/issues/218) |

## Summary

The public trading engine works. The delivery does not yet meet RFP-004 in full. Two audits checked 45 requirements and found 27 distinct problems: 3 high, 17 medium, 6 low and 1 info. The largest gaps are the private trading flow, which the SDK and app do not offer, and fee control: fees cannot change after setup, and there is no fixed address for protocol fees. Open a finding to see the exact requirement text and the code.

| Class | High | Medium | Low | Info | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| Bug | 3 | 15 | 3 | 0 | 21 |
| Outdated spec | 0 | 1 | 0 | 0 | 1 |
| Not due | 0 | 0 | 0 | 0 | 0 |
| Unverified | 0 | 1 | 3 | 1 | 5 |
| Total | 3 | 17 | 6 | 1 | 27 |

| ID | Severity | Class | Area | Finding (plain) | Requirement |
| --- | --- | --- | --- | --- | --- |
| [DEX-01](#dex-01-fees-and-admin-control-cannot-change-fully) | High | Bug | Program | Fees and admin control cannot change fully | F.6, F.11, R.4, U.12, S.5 |
| [DEX-02](#dex-02-no-fixed-recipient-for-protocol-fees) | Medium | Bug | Program | No fixed recipient for protocol fees | F.11, F.13, F.14 |
| [DEX-03](#dex-03-associated-token-accounts-cannot-fund-swaps-or-deposits) | Medium | Bug | Program | Associated token accounts cannot fund swaps or deposits | F.8 |
| [DEX-04](#dex-04-swaps-can-credit-another-namespaces-vault) | Low | Bug | Program | Swaps can credit another namespace's vault | R.2, F.14 |
| [DEX-05](#dex-05-pool-actions-do-not-record-price-history) | Medium | Outdated spec | Program | Pool actions do not record price history | F.10 |
| [DEX-06](#dex-06-swaps-cannot-create-a-receiving-account) | Low | Unverified | Program | Swaps cannot create a receiving account | P.1 |
| [DEX-07](#dex-07-simultaneous-swaps-are-unverified) | Medium | Unverified | Program | Simultaneous swaps are unverified | R.1 |
| [DEX-08](#dex-08-clients-lack-namespace-admin-actions) | High | Bug | Public | Clients lack namespace admin actions | U.12 |
| [DEX-09](#dex-09-swap-previews-hide-the-fee-split) | Medium | Bug | Public | Swap previews hide the fee split | U.9, U.11 |
| [DEX-10](#dex-10-confirmation-omits-price-and-expected-output) | Medium | Bug | Public | Confirmation omits price and expected output | U.9 |
| [DEX-11](#dex-11-pool-analytics-are-incomplete) | Medium | Bug | Public | Pool analytics are incomplete | U.5, U.11 |
| [DEX-12](#dex-12-swap-errors-hide-the-cause) | Medium | Bug | Public | Swap errors hide the cause | U.7 |
| [DEX-13](#dex-13-network-fee-estimates-are-missing) | Medium | Bug | Public | Network fee estimates are missing | U.8 |
| [DEX-14](#dex-14-the-app-hides-the-active-namespace) | Low | Bug | Public | The app hides the active namespace | U.10 |
| [DEX-15](#dex-15-basecamp-instructions-omit-a-package) | Medium | Bug (docs); assets unverified | Public | Basecamp instructions omit a package | U.2 |
| [DEX-16](#dex-16-clients-cannot-run-private-operations) | High | Bug | Private | Clients cannot run private operations | F.1, F.3, F.4, U.1, U.8, Privacy.1 |
| [DEX-17](#dex-17-no-preview-of-private-transaction-disclosures) | Medium | Bug | Private | No preview of private transaction disclosures | Privacy.2 |
| [DEX-18](#dex-18-no-check-for-a-private-return-account) | Medium | Bug | Private | No check for a private return account | Privacy.3 |
| [DEX-19](#dex-19-no-fresh-account-for-each-private-operation) | Medium | Bug | Private | No fresh account for each private operation | Privacy.4 |
| [DEX-20](#dex-20-automated-checks-skip-standalone-sequencer-tests) | Medium | Bug | Tests & docs | Automated checks skip standalone sequencer tests | S.2 |
| [DEX-21](#dex-21-some-required-behaviors-have-no-test) | Medium | Bug | Tests & docs | Some required behaviors have no test | S.4 |
| [DEX-22](#dex-22-full-transactions-lack-benchmarks) | Medium | Bug | Tests & docs | Full transactions lack benchmarks | P.3 |
| [DEX-23](#dex-23-operator-guides-have-broken-links-and-missing-steps) | Medium | Bug | Tests & docs | Operator guides have broken links and missing steps | S.5, S.7, U.6 |
| [DEX-24](#dex-24-test-guide-wrongly-promises-wallet-encryption) | Low | Bug | Tests & docs | Test guide wrongly promises wallet encryption | S.5 |
| [DEX-25](#dex-25-deployment-of-this-revision-is-unverified) | Low | Unverified | Tests & docs | Deployment of this revision is unverified | S.1, S.5 |
| [DEX-26](#dex-26-developer-guide-submission-is-unverified) | Low | Unverified | Tests & docs | Developer guide submission is unverified | S.6 |
| [DEX-27](#dex-27-app-design-submission-is-unverified) | Info | Unverified | Tests & docs | App design submission is unverified | S.8 |

## How to read this

| Class | Meaning |
| --- | --- |
| Bug | Code, documentation, or tests do not meet the specification. |
| Outdated spec | The code follows a different documented design. The specification owner decides which to change. |
| Not due | A recorded milestone decision assigns the requirement to a later delivery. |
| Unverified | The review lacks enough evidence to decide whether the requirement is met. |

| Severity | Meaning |
| --- | --- |
| High | A major required feature or control is missing or blocked. |
| Medium | A requirement is not met, or a meaningful user or verification gap remains. |
| Low | The issue is limited in scope or effect. |
| Info | The review requests evidence without establishing a defect. |

No finding is currently **Not due**. The [first milestone 1 review](https://github.com/logos-co/rfp/issues/217#issuecomment-6262964335) proposed splitting out privacy. The re-review still lists it as open. DEX-16 through DEX-19 move to **Not due** only if a recorded decision defers them.

<details>
<summary>Glossary</summary>

- **Namespace:** A separate set of pools, fee settings, and admin controls on one network.
- **Holding:** An account that stores a balance for one token. A pool's holding is called a vault.
- **Associated token account (ATA):** A holding whose owner authorizes spending through the token account program. The holding does not sign itself.
- **Program-derived address (PDA):** An address computed from a program and fixed inputs, not from a user's signing key.
- **Vault:** A token account controlled by a pool. Its balance should match the pool's records.
- **Oracle tick and time-weighted average price (TWAP):** A tick represents the latest price. Recorded prices over time are used to calculate the average.
- **Deshield and re-shield:** Move funds from a private account to a public account for an operation, then move the proceeds back to a private account.
- **Ephemeral account:** A new temporary public account for one private operation, with no previous activity on the network.
- **Standalone sequencer:** A separate service that processes transactions and orders them. It is not the in-process test runner.
- **Basecamp:** The Logos host application that installs and runs the trading mini-app.
- **Software development kit (SDK):** Code libraries used to build clients. The command-line interface (CLI) is a separate way to use the system from a terminal.
- **Continuous integration (CI):** Automated build and test checks.

</details>

## On-chain program

### DEX-01: Fees and admin control cannot change fully

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| High | Bug | F.6, F.11, R.4, U.12, S.5 | [`update_config.rs:23-52`][e1] |

Fees stay fixed after setup, and admins cannot give up control. This prevents changes to fees or removal of the admin role. Add authorized fee updates and a way for admins to give up control.

<details>
<summary>Requirement text</summary>

- [F.6](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L117-L120): “Trading fees are paid by the trader on every swap. The fee rate is set by the namespace admin authority and applies uniformly to all pools in that namespace; it is not selected per pool and is updatable after deployment. The fee is split between LPs and the protocol treasury per F.11.”
- [F.11][F.11]: “The namespace admin authority sets the protocol fee as a fraction of the trading fee, along with the treasury address that receives it, and both are updatable.”
- [R.4](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L218-L221): “A trading fee or protocol fee update applies only to fees accrued after the update, never retroactively to fees already earned by LPs. The split applied to a swap is the one in effect when the swap executes, and the swap respects the trader's slippage bound of F.7 regardless.”
- [U.12][U.12]: “setting the trading fee, the protocol fee, and the treasury address, plus the admin authority transfer and renunciation operations of RFP-001.”
- [S.5][S.5]: “how the admin authority configures the trading fee, protocol fee, and treasury.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-88b0fe36` (duplicates `F-bd461ee8`, `F-7b846f43`, `F-66b556f1`, `F-63f5fb94`); Devin `PUB-01` · Verified: `code`.

[`update_config.rs:23-52`][e1], [`lib.rs:93-96`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/core/src/lib.rs#L93-L96), `:340-359`, [`initialize.rs:43-73`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/initialize.rs#L43-L73).

```rust
    config_data.authority = new_authority;
```

Zero fees are valid. Test that updates preserve earned fees and that admin actions fail after renunciation.

</details>

### DEX-02: No fixed recipient for protocol fees

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | F.11, F.13, F.14 | [`withdraw_protocol_fees.rs:37-98`][e2] |

The program checks the admin's authority but does not store a treasury address. The admin can send protocol fees to any existing account for the same token. Store a treasury address and pay fees only to that address.

<details>
<summary>Requirement text</summary>

- [F.11][F.11]: “The namespace admin authority sets the protocol fee as a fraction of the trading fee, along with the treasury address that receives it, and both are updatable.”
- [F.13](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L154-L157): “The program supports any number of independent AMM namespaces. Anyone can permissionlessly create a namespace, seeding it with its own admin authority, trading fee, protocol fee, treasury, and pools, without permission from whoever deployed the program or from any existing namespace.”
- [F.14][F.14]: “Every state-changing instruction resolves pool, vault, treasury, and admin accounts against the namespace the pool belongs to, and rejects accounts belonging to another namespace.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-b06286a1`; Devin `PUB-01` · Verified: `code`.

[`lib.rs:586-605`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/core/src/lib.rs#L586-L605), [`withdraw_protocol_fees.rs:37-98`][e2].

**Cost:** Requires the configured admin's approval.

Test treasury changes, destination checks, and preservation of liquidity funds.

</details>

### DEX-03: Associated token accounts cannot fund swaps or deposits

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | F.8 | [`amm.rs:217-228`][e3] |

An associated token account can receive tokens but cannot fund a swap or deposit. Users must move their tokens first because the program expects the account itself to sign. Allow the account owner to authorize spending through the associated token account program.

<details>
<summary>Requirement text</summary>

- [F.8](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L123-L131): “The DEX program must be compatible with Associated Token Accounts (ATAs) for user-facing token accounts: when a trader or LP supplies an ATA derived per `(owner, mint)` pair (see [LP-0014](https://github.com/logos-co/lambda-prize/blob/main/prizes/LP-0014.md)), the program must accept it without requiring an alternative derivation. ATAs must not be forced on users; the program must also accept any valid SPL token account owned by the caller. Pool-side vault accounts may use program-derived addresses (PDAs) rather than ATAs, matching Solana DEX practice.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-415dcd5f`; Devin `PUB-02` · Verified: `test`. The gate log for the Bork run on the review machine shows this proof test failed (exit 101). It was not rerun independently.

[`amm.rs:217-228`][e3], `:310-325`, `:356-369`, [`swap.rs:381-390`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/swap.rs#L381-L390), [`add.rs:217-232`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/add.rs#L217-L232), [`ata.rs:49-73`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/ata/methods/guest/src/bin/ata.rs#L49-L73).

```rust
        #[account(mut, signer)] user_input_holding: AccountWithMetadata,
```

Test the correct owner, a wrong owner, and receipt into the account.

</details>

### DEX-04: Swaps can credit another namespace's vault

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Bug | R.2, F.14 | [`swap.rs:15-37`][e4] |

The swap can credit another namespace's vault with the trader's output. The vault balance changes without a matching update to its recorded reserves. Only allow valid recipient accounts.

<details>
<summary>Requirement text</summary>

- [R.2](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L212-L214): “An operation on a pool of one namespace never reads or writes the state, vaults, or treasury of another namespace, including when supplied with deliberately mismatched accounts from a second namespace.”
- [F.14][F.14]: “Every state-changing instruction resolves pool, vault, treasury, and admin accounts against the namespace the pool belongs to, and rejects accounts belonging to another namespace.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-5c24fe5b` · Verified: `test`. The gate log for the Bork run on the review machine shows this proof test failed (exit 101). It was not rerun independently.

[`swap.rs:15-37`][e4], `:56-71`, `:178-223`, `:392-408`, `:460-503`, `:669-685`, [`transfer.rs:7-27`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/token/src/transfer.rs#L7-L27), `:37-46`.

**Cost:** Requires an authorized, funded swap. The trader gives up the output; no gain from the other vault was shown.

The checks bind the pool's own vaults, not the recipient. No debit was shown. Test both swap modes and a valid recipient.

</details>

### DEX-05: Pool actions do not record price history

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Outdated spec | F.10 | [`update_current_tick.rs:45-59`][e5] |

Swaps and liquidity changes update the current price, not its history. A separate transaction records prices used for the time-weighted average. Decide whether to update the requirement or record the price in the same transaction.

<details>
<summary>Requirement text</summary>

- [F.10](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L137-L142): “Integrate the TWAP accumulator component delivered by [RFP-019](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-019-twap-oracle.md): every state-changing pool operation (swap, add liquidity, remove liquidity) invokes the component so the pool's price accumulators are maintained. If the component is not yet available when the DEX is delivered, the program must expose the integration point so the component can be hooked in later without redesigning pool state.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Devin `PUB-03` · Verified: `code`.

[`swap.rs:121-139`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/swap.rs#L121-L139), `:312`, [`add.rs:244-255`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/add.rs#L244-L255), [`remove.rs:258-268`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/remove.rs#L258-L268), [`update_current_tick.rs:45-59`][e5], [`record_tick.rs:105-148`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/twap_oracle/src/record_tick.rs#L105-L148), [`testnet-runbook.md:464-485`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/docs/testnet-runbook.md#L464-L485), [`amm.rs:2449-2505`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L2449-L2505).

The oracle hook exists. Test the timing of price updates and records.

</details>

<details>
<summary>Open question</summary>

Should F.10 allow a separate transaction for recording prices, or must each pool operation record them?

</details>

### DEX-06: Swaps cannot create a receiving account

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Unverified | P.1 | [`swap.rs:216-223`][e6] |

A swap cannot create the account that receives the output token. Users without that account need a separate transaction first. Confirm whether P.1 requires account creation in the same transaction.

<details>
<summary>Requirement text</summary>

- [P.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L225-L225): “A swap against an existing pool completes within a single LEZ transaction.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-1e9b0d04` · Verified: `unverified`.

[`swap.rs:216-223`][e6], `:496-503`, [`transfer.rs:12-27`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/token/src/transfer.rs#L12-L27), [`testnet-runbook.md:454-457`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/docs/testnet-runbook.md#L454-L457).

Regular transfers can create recipients. Test both swap modes once the scope is clear.

</details>

<details>
<summary>Open question</summary>

Does P.1 require the swap to create the trader's receiving account?

</details>

### DEX-07: Simultaneous swaps are unverified

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Unverified | R.1 | [`programs/amm/methods/guest/src/bin/amm.rs:325-342`][e7] |

Tests within one process submit swaps in sequence. They do not show how the pool behaves when users submit swaps at the same time. Run simultaneous swaps on a standalone sequencer and check the final balances.

<details>
<summary>Requirement text</summary>

- [R.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L210-L211): “Pool state must remain consistent under concurrent swap submissions; no double-spend or incorrect pool balance.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Devin `PUB-12` · Verified: `unverified`.

[`programs/amm/methods/guest/src/bin/amm.rs:325-342`][e7], [`programs/integration_tests/tests/amm.rs:1385-1414`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L1385-L1414), `:3546-3598`, [`ci.yml:193-214`][e20].

No double spend was shown. Compare final holdings and pool reserves with committed swaps.

</details>

<details>
<summary>Open question</summary>

Is there a test of simultaneous swaps on a standalone sequencer at this revision?

</details>

## Public path: developer tools and app

### DEX-08: Clients lack namespace admin actions

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| High | Bug | U.12 | [`admin.rs:20-72`][e8] |

The software development kit and app cannot create a namespace or set its fees or treasury. The command-line interface can create namespaces, but the full set of admin actions is still missing. Add the missing actions when the program supports them.

<details>
<summary>Requirement text</summary>

- [U.12][U.12]: “The SDK, CLI, and mini-app expose namespace creation and the admin operations for a namespace: setting the trading fee, the protocol fee, and the treasury address, plus the admin authority transfer and renunciation operations of RFP-001.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-6015cc2f`, `F-3a3dbea1`; Devin `PUB-01` · Verified: `code`.

[`admin.rs:20-72`][e8], [`amm_module_impl.h:66-87`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.h#L66-L87), [`testnet-runbook.md:304-331`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/docs/testnet-runbook.md#L304-L331), `:562-592`.

The kit supports admin transfer and fee withdrawal. The SPEL guide covers setup and fee withdrawal. Test authority checks and errors.

</details>

### DEX-09: Swap previews hide the fee split

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | U.9, U.11 | [`swap.rs:158-217`][e9] |

The preview shows one fee, and the app omits the protocol fee rate. Traders cannot see how much goes to the protocol or to liquidity providers. Show both rates and the fee split.

<details>
<summary>Requirement text</summary>

- [U.9][U.9]: “estimated output amount, effective price, price impact, and fee taken”
- [U.11][U.11]: “The mini-app and CLI show the current trading fee and protocol fee for the namespace in use. The swap preview of U.9 breaks the fee into the LP share and the protocol share.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-6fa085ed`, `F-a322c7ca`; Devin `PUB-09` · Verified: `code`.

[`swap.rs:158-217`][e9], `:228-305`, [`SwapSummary.qml:57-103`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapSummary.qml#L57-L103), [`PoolsPage.qml:33-51`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/pages/PoolsPage.qml#L33-L51), [`README.md:281-284`][e23], [`SwapCard.qml:477-497`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapCard.qml#L477-L497), [`PoolDetailPage.qml:889-942`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/pages/PoolDetailPage.qml#L889-L942).

The command-line interface reads rates. Check the fee split after rounding. See DEX-11 for pool revenue.

</details>

### DEX-10: Confirmation omits price and expected output

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | U.9 | [`SwapConfirmationSummary.qml:120-148`][e10] |

The swap preview does not show the effective price. When the trader enters an input amount, the confirmation shows the minimum output instead of the expected output. Show the effective price, expected output, and minimum allowed.

<details>
<summary>Requirement text</summary>

- [U.9][U.9]: “The mini-app must display a swap preview before the user confirms: estimated output amount, effective price, price impact, and fee taken, so the user can evaluate the trade before confirming.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-370960b5`; Devin `PUB-07` · Verified: `code`.

[`SwapConfirmationSummary.qml:120-148`][e10], [`SwapSummary.qml:26-156`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapSummary.qml#L26-L156), [`swap.rs:158-217`][e9].

On-chain limits work. Test both swap modes with price impact.

</details>

### DEX-11: Pool analytics are incomplete

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | U.5, U.11 | [`lib.rs:294-307`][e11] |

The pool page shows reserves, a price and a fee estimate. Users cannot compare pools by trading volume, the total value of assets in each pool, or revenue by fee type. Add those measures without showing individual positions.

<details>
<summary>Requirement text</summary>

- [U.5](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L180-L181): “Provide a pool analytics view showing aggregate volume, TVL, and fee revenue without revealing individual positions.”
- [U.11][U.11]: “The pool analytics view of U.5 reports protocol fee revenue separately from LP fee revenue.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-43ab21e7`; Devin `PUB-04` · Verified: `code`.

[`lib.rs:294-307`][e11], [`PoolDetailPage.qml:294-330`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/pages/PoolDetailPage.qml#L294-L330), `:865-945`.

The estimate uses reserves. Test against known trades without exposing individual positions.

</details>

### DEX-12: Swap errors hide the cause

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | U.7 | [`amm_module_impl.cpp:933-966`][e12] |

Some planning and wallet failures show the same empty-response error. Users cannot tell what to fix. Keep the reason for the failure and show it in the app.

<details>
<summary>Requirement text</summary>

- [U.7](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L185-L185): “Failed or rejected swaps must return clear, actionable error messages.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-2662e0be`; Devin `PUB-05` · Verified: `code`.

[`amm_module_impl.cpp:933-966`][e12], `:1035-1066`, [`AmmUiBackend.cpp:316-328`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/src/AmmUiBackend.cpp#L316-L328), [`SwapCard.qml:530-554`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapCard.qml#L530-L554).

```cpp
        AMM_TRACE("swapExactInput: FAIL amm_swap_exact_in_plan: " << planResult.error);
        return {};
```

Missing-wallet and missing-payer errors are already clear. Test planning failure and sequencer rejection separately.

</details>

### DEX-13: Network fee estimates are missing

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | U.8 | [`SwapSummary.qml:57-80`][e13] |

Swap and liquidity confirmations show no estimate for the network fee. Traders see the trading fee but not the cost of sending the transaction. Show the two charges separately before approval.

<details>
<summary>Requirement text</summary>

- [U.8][U.8]: “Before each swap or liquidity operation, the mini-app must show the estimated transaction fee.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-071dacdd`; Devin `PUB-06` · Verified: `code`.

[`SwapSummary.qml:57-80`][e13], [`LiquidityConfirmationSummary.qml:13-40`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/liquidity/LiquidityConfirmationSummary.qml#L13-L40), [`RemoveLiquidityDialog.qml:381-429`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/liquidity/RemoveLiquidityDialog.qml#L381-L429), [`WalletControl.qml:684-711`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/shared/wallet/qml/WalletControl.qml#L684-L711), [`SwapCard.qml:487-495`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapCard.qml#L487-L495), [`LiquidityPage.qml:393-408`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/pages/LiquidityPage.qml#L393-L408).

The wallet only checks for a funded payer. Test each confirmation with a known estimate.

</details>

### DEX-14: The app hides the active namespace

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Bug | U.10 | [`AmmUiBackend.cpp:54-65`][e14] |

The app ties each network to one namespace. Users cannot see or change the active namespace. Show the current namespace and let users choose another one on the same network.

<details>
<summary>Requirement text</summary>

- [U.10](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L195-L197): “The SDK, CLI, and mini-app let the caller select which namespace to operate against, and the mini-app shows the active namespace. Pools of different namespaces are never mixed in quotes, routing, or LP position listings.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-3d804670`; Devin `PUB-08` · Verified: `code`.

[`AmmUiBackend.cpp:54-65`][e14], [`SettingsModal.qml:216-266`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/chrome/SettingsModal.qml#L216-L266), [`amm_module_impl.cpp:393-420`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.cpp#L393-L420).

No mixing of quotes or positions was found. Test that both follow the chosen namespace.

</details>

### DEX-15: Basecamp instructions omit a package

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug (docs); assets unverified | U.2 | [`apps/amm/README.md:90-132`][e15] |

The install guide lists the wallet and the app but omits the trading module the app needs. The effect on a clean install is not verified. Document the module and test a clean install.

<details>
<summary>Requirement text</summary>

- [U.2](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L173-L174): “Provide a Logos mini-app GUI with local build instructions, downloadable assets, and loadable in Logos app (Basecamp) via git repo.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-448cee04` (pending, not confirmed by Bork's verifier); Devin `PUB-10` · Verified: `code` (README read; clean install not run).

[`apps/amm/README.md:90-132`][e15], `:148-157`, [`metadata.json:12`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/metadata.json#L12), [`apps/amm/flake.nix:23-41`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/flake.nix#L23-L41), [`flake.nix:318-327`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/flake.nix#L318-L327), [`modules/amm/README.md:273-279`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/README.md#L273-L279), [builder:160–202](https://github.com/logos-co/logos-module-builder/blob/fd07679ecfa1b2d8cfdd06799f3e03ed385b57f6/lib/mkLogosQmlModule.nix#L160-L202).

The module guide lists all three packages. The build exports the module separately. No GitHub release assets or Git-load steps were found. Test both routes and a swap.

</details>

<details>
<summary>Open question</summary>

Where can users download the packages? Can Basecamp load them from Git or install the missing module automatically?

</details>

## Private path

### DEX-16: Clients cannot run private operations

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| High | Bug | F.1, F.3, F.4, U.1, U.8, Privacy.1 | [`amm_module_impl.cpp:384-385`][e16] |

The software development kit and app only submit public operations. Users cannot move funds from a private account, trade, and return proceeds to private storage in the required flow. Check that the private balance covers the operation and fee, then move both to the public account in one transaction.

<details>
<summary>Requirement text</summary>

- [F.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L101-L103): “Implement an automated market maker (AMM) program on LEZ with public liquidity pools supporting the deshield→swap→re-shield interaction pattern for privacy-preserving trading.”
- [F.3](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L105-L108): “Liquidity providers can add and withdraw liquidity directly from a public account, or via the deshield→interact→reshield pattern from a private account. The LP position is public on-chain; when using a private account, which private account originated or received the funds is not traceable.”
- [F.4](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L109-L113): “Traders can swap tokens directly from a public account, or via the deshield→swap→re-shield pattern from a private account. Trade size and direction are visible on-chain; when using a private account, which private account originated the funds or where they go after re-shielding is not traceable.”
- [U.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L167-L172): “Provide an SDK that can be used to build Logos modules for interacting with the DEX (swapping, pool creation, liquidity management). When the user interacts from a private account, the SDK must handle the atomic deshield — transferring both the swap token and a small amount of native token for gas — as a single indivisible action, preventing accidental privacy leaks from externally funding account A.”
- [U.8][U.8]: “When the user interacts from a private account, it must also confirm that the shielded balance covers both the operation amount and fees within the single deshield action; a clear, actionable error must be shown if the balance is insufficient (preventing partial deshields that could leave funds stranded in an ephemeral account).”
- [Privacy.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L257-L260): “The mini-app and SDK must support both direct public account interaction and the deshield→swap→re-shield pattern for private account interaction. When a user interacts from a private account, the SDK must enforce the complete deshield→swap→re-shield pattern — the re-shield step must not be skippable.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-be53afb2`, `F-87d10205`, `F-28c34d2e`, `F-711fa97a`; Devin `PRV-01` · Verified: `code`.

[`amm_module_impl.cpp:384-385`][e16], `:938-966`, `:1039-1066`, [`README.md:59-86`][l2], [`amm.rs:3982-4123`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L3982-L4123).

```cpp
        if (!entry.value("is_public", true)) continue;
```

The account picker hides private accounts. Direct program tests do not cover the clients. A different revision showed proof errors or hangs. Test failure without leaving funds in the public account.

</details>

<details>
<summary>Open question</summary>

Is the private flow due in milestone 1 or explicitly assigned to a later milestone?

</details>

### DEX-17: No preview of private transaction disclosures

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | Privacy.2 | [`SwapConfirmationSummary.qml:1-151`][e17] |

There is no confirmation screen for private operations. Users cannot see what will become public before approving an action. List the public and private fields in each private confirmation.

<details>
<summary>Requirement text</summary>

- [Privacy.2](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L261-L266): “When interacting from a private account, the mini-app must display a pre-confirmation summary for each operation that clearly identifies what will be visible on-chain (trade size, direction, pool address, ephemeral intermediary account) and what will remain private (the originating private account, the destination of re-shielded tokens, and any link between separate swaps by the same user).”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-13df0d2b`; Devin `PRV-01` · Verified: `code`.

[`SwapConfirmationSummary.qml:1-151`][e17].

Test the disclosure list without exposing private accounts.

</details>

<details>
<summary>Open question</summary>

Is this requirement due in milestone 1 or explicitly assigned to a later milestone?

</details>

### DEX-18: No check for a private return account

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | Privacy.3 | [`amm_module_impl.cpp:863-1066`][e18] |

The client has no step that returns funds to a private account. It therefore has no check for a valid private destination. When adding that step, reject public destinations before submitting.

<details>
<summary>Requirement text</summary>

- [Privacy.3](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L267-L270): “When interacting from a private account, the SDK must validate that the target account for re-shielding swap output is a private (shielded) account before submitting the transaction, and reject the operation with an explicit error if it is not.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-e81bd1ca`; Devin `PRV-01` · Verified: `code`.

[`amm_module_impl.cpp:863-1066`][e18].

No public destination was accepted in a working flow. Test rejection of public accounts and acceptance of private ones.

</details>

<details>
<summary>Open question</summary>

Is this requirement due in milestone 1 or explicitly assigned to a later milestone?

</details>

### DEX-19: No fresh account for each private operation

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | Privacy.4 | [`amm_module_impl.cpp:863-1066`][e18] |

There is no private flow that creates a temporary public account for each action. Separate private operations cannot get the isolation the specification requires. Create a fresh public account each time.

<details>
<summary>Requirement text</summary>

- [Privacy.4](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L271-L274): “The ephemeral public account (account A) created during the deshield step must never be reused across operations. Each swap or liquidity operation from a private account must use a freshly generated account with no prior on-chain history.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-076cc39d`; Devin `PRV-01` · Verified: `code`.

[`amm_module_impl.cpp:863-1066`][e18].

No reuse was shown. Test that two actions use different accounts with no history.

</details>

<details>
<summary>Open question</summary>

Is this requirement due in milestone 1 or explicitly assigned to a later milestone?

</details>

## Automated checks, tests and documentation

### DEX-20: Automated checks skip standalone sequencer tests

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | S.2 | [`ci.yml:193-214`][e20] |

The automated build runs integration tests inside the test process only. A passing run does not test the app against a separate sequencer. Start a standalone sequencer in the automated checks and run the end-to-end tests.

<details>
<summary>Requirement text</summary>

- [S.2](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L236-L237): “End-to-end integration tests run against a LEZ sequencer (standalone mode) and are included in CI.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-e97ceece`; Devin `PUB-14` · Verified: `code`.

[`ci.yml:193-214`][e20], [`amm.rs:1257-1287`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L1257-L1287), `:1385-1414`, [`apps/amm/tests/README.md:49-60`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/tests/README.md#L49-L60), `:86-90`, [`flake.nix:168-177`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/flake.nix#L168-L177), `:481-505`, [`apps/amm/README.md:411-417`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/README.md#L411-L417), [auto-export rule](https://github.com/logos-co/logos-module-builder/blob/fd07679ecfa1b2d8cfdd06799f3e03ed385b57f6/lib/mkLogosQmlModule.nix#L206-L246).

The build generates `.#integration-test`. The manual suite needs setup. Test committed state and verify that errors fail the job.

</details>

### DEX-21: Some required behaviors have no test

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | S.4 | [`amm.rs:1962-2064`][e21] |

Current tests miss private client operations, fee changes, simultaneous swaps, and performance limits. A passing suite does not show that every requirement is met. Map each requirement to a test and fill those gaps.

<details>
<summary>Requirement text</summary>

- [S.4](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L239-L240): “Every hard requirement in Functionality, Usability, Reliability, and Performance has at least one corresponding test.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Devin `PUB-15` · Verified: `code`.

[`amm.rs:1962-2064`][e21], `:3601-3695`, `:4078-4123`, [`VALIDATION.md:6-28`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/VALIDATION.md#L6-L28), `:45-57`.

Direct program tests do not exercise private client steps. Check that each requirement has a runnable test.

</details>

### DEX-22: Full transactions lack benchmarks

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | P.3 | [`README.md:1-24`][e22] |

The project lacks compute and size measurements for complete trading transactions. Oracle measurements and individual instruction sizes do not show whether the transactions fit the development network limits. Measure swaps, deposits, withdrawals and pool creation against those limits.

<details>
<summary>Requirement text</summary>

- [P.3](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L228-L231): “Compute unit usage and transaction size of each operation (swap, add liquidity, remove liquidity, pool creation) must be documented and benchmarked against LEZ devnet limits; LEZ's per-transaction compute budget and block size may change during testnet.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-c88fe04a`; Devin `PUB-13` · Verified: `code`.

[`README.md:1-24`][e22], `:42-76`, [`amm_module_impl.cpp:943-949`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.cpp#L943-L949), [`twap_cycle_bench.rs:1-506`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/benchmark/tests/twap_cycle_bench.rs#L1-L506).

Add a repeatable size and compute check.

</details>

### DEX-23: Operator guides have broken links and missing steps

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Medium | Bug | S.5, S.7, U.6 | [`apps/amm/README.md:281-284`][e23] |

The guides have broken links and omit steps for liquidity and fee administration. They also do not explain what each private action makes public. Fix the links and document the missing workflows and privacy details.

<details>
<summary>Requirement text</summary>

- [S.5][S.5]: “A README documents end-to-end usage: deployment steps, program addresses, and step-by-step instructions for interacting with the DEX via CLI and front-end (pool creation, swapping, LP management). It must also document how to create a namespace, how namespace and pool addresses are derived, and how the admin authority configures the trading fee, protocol fee, and treasury.”
- [S.7](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L250-L252): “Submit a [doc packet][l3] for the CLI, covering the core operator/user journey.”
- [U.6](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L182-L184): “Documentation must clearly explain what information is public vs. private for each action (trade size and pool used are visible on-chain; the private account that originated or receives the funds is not traceable).”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-94dd7963`, `F-1eeca8f6`, `F-3e723097`, `F-3b90862f`; Devin `PUB-11`, `PRV-02` · Verified: `code`.

[`modules/amm/README.md:59-86`][l2], `:292-295`, [`apps/amm/README.md:281-284`][e23], [`testnet-runbook.md:21-47`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/docs/testnet-runbook.md#L21-L47), `:268-302`, `:304-331`, `:421-457`, `:562-592`, `:594`, `:842-849`, [`amm_pdas.rs:23-39`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/examples/amm_pdas.rs#L23-L39), [`amm-idl.json:238-402`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/artifacts/amm-idl.json#L238-L402), [`DEPLOYMENTS.md:39-56`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/DEPLOYMENTS.md#L39-L56), [`lib.rs:632-684`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/core/src/lib.rs#L632-L684), [logos-docs#368][l4].

Derivation is documented. The example only uses zero. Add a custom namespace number if supported. Check links and run the updated steps.

</details>

### DEX-24: Test guide wrongly promises wallet encryption

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Bug | S.5 | [actual pinned wallet storage][e24] |

The test guide says a password protects stored keys. The audited wallet ignores that password when creating or restoring a wallet and writes unencrypted data. Correct the guide and verify the steps with a test wallet.

<details>
<summary>Requirement text</summary>

- [S.5][S.5]: “A README documents end-to-end usage”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-9ac62d30` · Verified: `code`.

[`apps/amm/tests/README.md:94-101`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/tests/README.md#L94-L101), [`apps/amm/README.md:38-48`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/README.md#L38-L48), [`flake.nix:19-21`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/flake.nix#L19-L21), [actual pinned wallet storage][e24].

This finding only applies to the wallet version in the audited app.

</details>

### DEX-25: Deployment of this revision is unverified

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Unverified | S.1, S.5 | [`DEPLOYMENTS.md:5-22`][e25] |

The deployment log only identifies an older build. It does not show that this revision was deployed and tested on a development or test network. Link the network, program address, exact revision and test results.

<details>
<summary>Requirement text</summary>

- [S.1](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L235-L235): “The DEX program is deployed and tested on LEZ devnet/testnet.”
- [S.5][S.5]: “deployment steps, program addresses”

</details>

<details>
<summary>Evidence and code</summary>

Source: Bork `F-6a97ec82`; Devin `PUB-16` · Verified: `unverified`.

[`DEPLOYMENTS.md:5-22`][e25], `:39-63`, [`Cargo.toml:10-11`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/Cargo.toml#L10-L11).

The record is for v0.2.4 (tag `v2.0.1`); the code targets v0.2.5-rc2. Verify a swap and the resulting state.

</details>

<details>
<summary>Open question</summary>

Where is the deployment record and test result for this revision?

</details>

### DEX-26: Developer guide submission is unverified

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Low | Unverified | S.6 | [`README.md:11-89`][e26] |

The command-line guide was submitted, but no submitted software development kit guide was found. Reviewers cannot verify the required developer examples. Link or submit a guide for pool creation, swaps and liquidity operations.

<details>
<summary>Requirement text</summary>

- [S.6](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L246-L249): “Submit a [doc packet][l3] for the SDK, covering the developer integration journey for pool creation, swapping, and liquidity management.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Devin `PUB-17` · Verified: `unverified`.

[`README.md:11-89`][e26], `:142-178`, [logos-docs#368][l4].

The repository has integration notes, and a submission may exist elsewhere. Run the guide's examples.

</details>

<details>
<summary>Open question</summary>

Where is the guide or its submission record?

</details>

### DEX-27: App design submission is unverified

| Severity | Class | Requirement | Evidence |
| --- | --- | --- | --- |
| Info | Unverified | S.8 | [`VALIDATION.md:40-57`][e27] |

The reviewed material does not link to Figma designs or an equivalent. Reviewers cannot compare the app with the intended design. Link the design for the swap, liquidity and pool screens.

<details>
<summary>Requirement text</summary>

- [S.8](https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L253-L253): “Provide Figma designs or equivalent for the mini-app GUI.”

</details>

<details>
<summary>Evidence and code</summary>

Source: Devin `PUB-18` · Verified: `unverified`.

[`VALIDATION.md:40-57`][e27], [`SwapPage.qml:1-42`](https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/pages/SwapPage.qml#L1-L42), [ecosystem#183][l1].

Validation notes do not replace design files.

</details>

<details>
<summary>Open question</summary>

Where are the Figma designs or the accepted equivalent?

</details>

## How to reproduce and re-verify

Repeat the source and test checks at the pins above. To verify fixes, record the new pins and save the result for each DEX ID.

<details>
<summary>Inputs</summary>

- Code and specification: pins above.
- Bork: `8cd4a026cd5dd0f49d9dc9ce3bf6a0cbaceea2a3`. Image: `bork/worker-logos-rfp:risc0` (8.6 GB, label `variant=risc0`, built on `bork/worker-logos-rfp:8cd4a02`).
- Toolchain in the image: `r0vm` 3.1.0, `cargo-risczero` 3.1.0, guest Rust 1.94.1, Claude Code 2.1.331. Host Rust in the worker: `rustc 1.94.0 (4a4ef493e)`, `cargo 1.94.0 (85eff7c80)`. Image ID `sha256:77d39dd2437d4e09e6ad7c9b01ead8a206ea643a5c7cb09764088b13e8408d5b` (local build; registry digest: not recorded).
- Environment: isolated `BORK_HOME=$HOME/.bork-rfp`; `BORK_FINDING_PRODUCER=claude/claude-opus-5-5`, `BORK_FINDING_VERIFIER=claude/claude-sonnet-5-5`, `BORK_REPORT_PRODUCER=claude/claude-sonnet-5-5`, `BORK_CLAUDE_EFFORT=high`, `BORK_WORKER_TIMEOUT=7200`. Other settings: not recorded.
- Spec section SHA-256 prefix per task `input.json`: functionality `584f68371142`, usability `c96b1c6b2dd8`, reliability `b31f7db5d628`, performance `83408fe9f564`, supportability `00b0cd8d79d5`, privacy `45f9a2b1810a`. `40f60a424657` is the whole Hard Requirements section from the first run, per `bork brief check` (its `input.json`: `177c29cfd54d`).
- Worker had no network, Nix, or Qt.

</details>

<details>
<summary>Bork run</summary>

| Task (`rfp-004-` prefix) | Brief scope | Gate exit |
| --- | --- | ---: |
| functionality | F.1–F.14; excludes soft multi-hop routing | 101 |
| usability | U.1–U.12 | 0 |
| reliability | R.1–R.4 | 101 |
| performance | P.1–P.3 | 101 |
| supportability | S.1–S.8; S.3, S.4, S.6–S.8 not traced | 101 |
| privacy | Privacy.1–Privacy.4 | 0 |

The harness ran `RISC0_DEV_MODE=1 cargo test -p amm_program` with audit proof tests and saved each task's output as `gate-rfp-004-<section>.log`. All six passed 149 existing tests. Exit 101 means a proof test failed; Cargo stopped at the first failing test binary. Briefs, exact prompts and proof-test branches are kept on the reviewer's machine; ask @glitchminer. Log copy before collect: `docker cp "bork-w-$id:/tmp/repro-setup.log" "$L/gate-$n.log"`. Task IDs, table order, prefix `20261124T`: `134250-78adbf`, `135749-471202`, `141358-373d00`, `142343-12ec52`, `143226-88ca43`, `144243-68345a`.

</details>

<details>
<summary>Devin audit</summary>

Trace all 45 hard requirement IDs to pinned source in the program, tools, app, token accounts and oracle. Check tests, documentation, and published build results. Mark gaps separately from missing evidence. Devin did not run Bork.

</details>

<details>
<summary>Local gate for the Devin audit</summary>

From the repo root at the code pin, with Rust 1.94.0:

```sh
RISC0_DEV_MODE=1 cargo test -p amm_program
```

Recorded exit 0: 149 passed, 0 failed. Not rerun in this merge.

</details>

<details>
<summary>Per-finding re-check</summary>

| ID | How to check it is fixed |
| --- | --- |
| DEX-01 | Test fee updates, admin renunciation, and unchanged earned fees. |
| DEX-02 | Test treasury updates and rejection of other destinations. |
| DEX-03 | Test swaps and deposits authorized by an associated token account owner. |
| DEX-04 | Verify both swap modes reject another namespace's vault. |
| DEX-05 | Check the agreed F.10 text and test price update timing. |
| DEX-06 | Confirm P.1 scope and test both swap modes with a new receiving account. |
| DEX-07 | Run simultaneous swaps on a standalone sequencer; check balances. |
| DEX-08 | Test namespace creation and admin actions in each required client. |
| DEX-09 | Compare displayed rates and fee split with actual fees. |
| DEX-10 | Check effective price and expected output in both swap modes. |
| DEX-11 | Check pool volume, value, and separate fee revenue against known trades. |
| DEX-12 | Check error messages for planning, wallet, and sequencer failures. |
| DEX-13 | Check network-fee estimates before swaps and liquidity actions. |
| DEX-14 | Switch namespaces and check the label, quotes, and positions. |
| DEX-15 | On clean Basecamp, follow the guide and check downloads and Git loading. |
| DEX-16 | Test private swaps and liquidity on success and failure. |
| DEX-17 | Check that the preview lists public and private fields. |
| DEX-18 | Verify rejection of public return accounts before submission. |
| DEX-19 | Check two private operations use different, unused public accounts. |
| DEX-20 | Find a passing automated test run with a standalone sequencer. |
| DEX-21 | Match each hard requirement to a runnable test. |
| DEX-22 | Check full compute and size for all four operations against network limits. |
| DEX-23 | Check links and follow the updated operator and privacy guides. |
| DEX-24 | Compare the test guide's password claims with wallet storage. |
| DEX-25 | Find a deployment address and test results for the same pin. |
| DEX-26 | Find the developer guide submission and run its examples. |
| DEX-27 | Find Figma designs or an accepted equivalent. |

</details>

<details>
<summary>Requirements met</summary>

F.2, F.5, F.7, F.9, F.12, P.2, R.3, U.3, U.4 and S.3 are met at this revision, based on the code or passing tests. F.13 and F.14 are met except for the treasury (DEX-02) and the vault check (DEX-04).

</details>

<details>
<summary>Rejected or narrowed claims</summary>

- **Package test target:** The build generates `.#integration-test` from existing test scripts. DEX-20 covers the missing automated run, not a missing target.
- **Address derivation:** The runbook and `DEPLOYMENTS.md` explain it. DEX-23 covers the example that only uses zero as the namespace number.
- **Namespace fallback:** If a network omits `ammConfigId`, the app uses `AMM_CONFIG_ID`. U.10 allows this.
- **Older proposal:** Per-pool fee tiers and `RecoverSurplus` are not findings. The pinned specification uses fees set per namespace and excludes `RecoverSurplus`.

</details>

<details>
<summary>Test limits (not run)</summary>

This review merged two audits and checked their evidence at the pinned revisions. In the findings, `test` marks a reported failing test, `code` marks source evidence, and `unverified` means more evidence is needed.

We did not run Basecamp, Nix builds, a standalone sequencer, proof generation, or live network checks. The milestone 1 re-review used v0.2.5-rc2 at another revision; milestone 2 targets v0.4.

Bork reported `RISC0_DEV_MODE=1 cargo test -p amm_program`: `149 passed; 0 failed`. [Automated checks at the audited revision](https://github.com/logos-blockchain/lez-programs/actions/runs/45170423697) passed. These results do not cover the two separate failing tests in DEX-03 and DEX-04.

</details>

## Decisions for the spec owner

1. **DEX-05:** Should F.10 allow the separate price record, or should every pool operation record it?
2. **DEX-06:** Does P.1 include creating an account to receive the swap output?
3. **DEX-16 to DEX-19:** Is the private path due in milestone 1, or should it move to a later milestone?

[F.11]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L143-L149
[U.12]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L202-L206
[S.5]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L241-L245
[F.14]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L158-L163
[U.9]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L192-L194
[U.11]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L198-L201
[U.8]: https://github.com/logos-co/rfp/blob/a4323366516228875b61c72d12acb59b3d46cab7/RFPs/RFP-004-privacy-preserving-dex.md#L186-L191

[e1]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/update_config.rs#L23-L52
[e2]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/withdraw_protocol_fees.rs#L37-L98
[e3]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/methods/guest/src/bin/amm.rs#L217-L228
[e4]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/swap.rs#L15-L37
[e5]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/twap_oracle/src/update_current_tick.rs#L45-L59
[e6]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/src/swap.rs#L216-L223
[e7]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/methods/guest/src/bin/amm.rs#L325-L342
[e8]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/ffi/src/api/admin.rs#L20-L72
[e9]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/ffi/src/api/swap.rs#L158-L217
[e10]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapConfirmationSummary.qml#L120-L148
[e11]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/amm/core/src/lib.rs#L294-L307
[e12]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.cpp#L933-L966
[e13]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapSummary.qml#L57-L80
[e14]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/src/AmmUiBackend.cpp#L54-L65
[e15]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/README.md#L90-L132
[e16]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.cpp#L384-L385
[e17]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/qml/components/swap/SwapConfirmationSummary.qml#L1-L151
[e18]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/src/amm_module_impl.cpp#L863-L1066
[e20]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/.github/workflows/ci.yml#L193-L214
[e21]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/integration_tests/tests/amm.rs#L1962-L2064
[e22]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/programs/benchmark/README.md#L1-L24
[e23]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/README.md#L281-L284
[e24]: https://github.com/logos-blockchain/logos-execution-zone/blob/6477ce33c311f82b962daae1583fb647b9894b39/lez/wallet/src/storage.rs#L32-L90
[e25]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/DEPLOYMENTS.md#L5-L22
[e26]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/README.md#L11-L89
[e27]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/apps/amm/VALIDATION.md#L40-L57
[l1]: https://github.com/logos-co/ecosystem/issues/183
[l2]: https://github.com/logos-blockchain/lez-programs/blob/1cfaa5e3446a684e6e9b61cfb243038dae6465ea/modules/amm/README.md#L59-L86
[l3]: https://github.com/logos-co/logos-docs/issues/new?template=doc-packet.yml
[l4]: https://github.com/logos-co/logos-docs/issues/368


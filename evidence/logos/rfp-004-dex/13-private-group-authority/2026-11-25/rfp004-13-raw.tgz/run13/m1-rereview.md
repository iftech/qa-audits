**M1 re-review update — partial, on-chain against LEZ v0.2.5-rc2.** (Follows our 2026-10-19 M1 review at v0.2.4.) Reviewed at lez-programs `main` @ `071375c`, standalone v0.2.5-rc2 sequencer, `RISC0_DEV_MODE=1`.

### Program/runtime level
- **Public swaps: confirmed working end-to-end, live** — a real swap debited/credited both holdings with the exact constant-product-minus-fee amounts.
- **Private / group-owned-authority path: UNCONFIRMED.** Running the full `programs/integration_tests/tests/amm.rs` suite live, 46 tests passed (all public-path), but **every** test exercising a private-namespace owner or group-owned authority through the circuit either failed with `CircuitProvingError("rx len failed")` or hung. Whether that's a real regression or an artifact of the dev-mode/sandbox environment is **not yet isolated** — it needs a clean-environment, real-proving re-run. (This corrects an earlier file-read that reported these as passing.)

### UI / module / docs (M1-004-01..08): not re-tested here
These eight findings live in the Basecamp app + module and need a GUI host to re-test meaningfully — out of scope for this on-chain pass. A code-read at this same commit found all eight still present. A separate Basecamp UX re-test is the right venue and is pending.

### Net
The on-chain swap engine is solid; the two open questions for M1 acceptance are (a) the private-swap circuit path (resolve the errored/hung tests) and (b) the eight UI findings (Basecamp re-test).

Full on-chain report + logs: https://data.vpavlin.xyz/lez-m1-onchain-v025/

*(M2 targets LEZ v0.4 — no release yet; see the separate v0.4 port-readiness assessment, where the AMM's async-payout risk is the headline item.)*


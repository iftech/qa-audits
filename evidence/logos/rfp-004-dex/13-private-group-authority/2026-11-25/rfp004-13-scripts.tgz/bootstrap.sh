#!/usr/bin/env bash
set -euo pipefail
work=/home/qa/work
logs=$work/run13
exec >"$logs/bootstrap.log" 2>&1
cd "$work/lez-programs"
date -Is
df -h "$work"
export GITHUB_TOKEN="$(/usr/bin/gh auth token)"
export HOME="$work/proving-home"
export CARGO_HOME="$work/cargo" RUSTUP_HOME="$work/rustup"
export PATH="$CARGO_HOME/bin:$HOME/.risc0/bin:$PATH"
mkdir -p "$HOME" "$work/tmp"
export TMPDIR="$work/tmp"
curl --retry 2 -fsSL https://sh.rustup.rs | sh -s -- -y --no-modify-path --profile minimal --default-toolchain 1.94.0
rustc -Vv
cargo -V
curl --retry 2 -fsSL https://risczero.com/install | bash
rzup --version
rzup install
version="$(awk '/^name = "risc0-zkvm"$/ { getline; gsub(/version = |"/, ""); print; exit }' Cargo.lock)"
: "${version:?risc0-zkvm is not in Cargo.lock}"
for component in r0vm cargo-risczero; do
  rzup install --force "$component" "$version"
  rzup default "$component" "$version"
done
rzup show
r0vm --version
cargo risczero --version
date -Is
df -h "$work"

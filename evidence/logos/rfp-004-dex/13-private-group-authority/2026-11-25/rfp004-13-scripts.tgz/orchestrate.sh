#!/usr/bin/env bash
set -uo pipefail
logs=/home/qa/work/run13
exec >>"$logs/orchestrate.log" 2>&1
date -Is
while systemctl --quiet is-active lez-rfp004-13-build.service; do sleep 15; done
grep -q '"reason":"build-finished","success":true' "$logs/build-cargo.jsonl" || { echo build failed; exit 1; }
bash "$logs/run-cases.sh" dev "$logs/cases.txt"
stop=$(date -d '2026-11-25 04:40' +%s)
bash "$logs/run-cases.sh" real "$logs/cases-real.txt" "$stop"
[[ $(date +%s) -lt $stop ]] && bash "$logs/interrupt.sh"
date -Is

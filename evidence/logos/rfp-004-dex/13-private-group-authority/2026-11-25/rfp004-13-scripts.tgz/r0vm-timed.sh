#!/usr/bin/env bash
set -euo pipefail
if [[ "${1-}" == --version ]]; then
  exec "$PROVING_R0VM" "$@"
fi
log="$(mktemp "$PROVING_RUN_DIR/r0vm.$(date +%s%N).XXXXXXXX.log")"
printf 'Started: %s; argv:' "$(date -Ins)" >"$log"
printf ' %q' "$@" >>"$log"
printf '\n' >>"$log"
exec /usr/bin/time -a -o "$log" -v "$PROVING_R0VM" "$@" >>"$log" 2>&1

#!/usr/bin/env bash
# Kill the privacy-circuit r0vm 60 s into proving, then rerun the same case.
set -uo pipefail
source /home/qa/work/run13/environment.sh
unset RISC0_DEV_MODE BONSAI_API_URL BONSAI_API_KEY
export RISC0_PROVER=ipc RISC0_EXECUTOR=ipc RISC0_INFO=1 RUST_LOG=risc0_zkvm=info
export PROVING_R0VM="$(readlink -f "$(command -v r0vm)")" RISC0_SERVER_PATH="$logs/r0vm-timed.sh"
exec >>"$logs/interrupt.log" 2>&1
tok=$(python3 -c 'import json,sys
for l in open(sys.argv[1]):
  if l.startswith("{"):
    i=json.loads(l)
    if i.get("reason")=="compiler-artifact" and i["target"]["name"]=="token" and i.get("executable"): print(i["executable"])' "$logs/build-cargo.jsonl")
case=token_mint_private_unauthorized
for phase in interrupted rerun; do
  export PROVING_RUN_DIR="$logs/interrupt/$phase"; rm -rf "$PROVING_RUN_DIR"; mkdir -p "$PROVING_RUN_DIR"
  echo "$(date -Is) START $phase"
  t0=$(date +%s.%N)
  "$tok" --exact $case --nocapture --test-threads=1 >"$PROVING_RUN_DIR/test.log" 2>&1 &
  pid=$!
  if [[ $phase == interrupted ]]; then
    # wait for the second r0vm session (the circuit proof), then 60 s more
    for i in $(seq 1 600); do
      n=$(ls "$PROVING_RUN_DIR"/r0vm.*.log 2>/dev/null | wc -l); [[ $n -ge 2 ]] && break; sleep 1
    done
    sleep 60
    ps -eo pid,ppid,etimes,rss,args | grep '[r]0vm' | grep -v r0vm-timed
    victim=$(pgrep -f "^$PROVING_R0VM" | tail -1)
    echo "$(date -Is) kill -TERM r0vm pid=$victim"
    kill -TERM "$victim"
  fi
  rc=0; wait $pid || rc=$?
  echo "$(date -Is) END $phase exit=$rc wall=$(echo "$(date +%s.%N) - $t0" | bc)s"
  sleep 2; echo "r0vm left after $phase: $(pgrep -fc "^$PROVING_R0VM" || true)"
  tail -5 "$PROVING_RUN_DIR/test.log"
done

#!/usr/bin/env python3
"""Build the #13 draft comment from run13 logs."""
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parent
ansi = re.compile(r"\x1b\[[0-9;]*m")
SHA = "1cfaa5e3446a684e6e9b61cfb243038dae6465ea"
BLOB = f"https://github.com/logos-blockchain/lez-programs/blob/{SHA}/programs/integration_tests/tests"
cases = [tuple(l.split()) for l in (root / "cases.txt").read_text().splitlines() if l.strip() and not l.startswith("#")]
meta = {l.split("\t")[0]: l.rstrip("\n").split("\t")[1:] for l in (root / "cases-meta.tsv").read_text().splitlines() if l.strip()}


def m(text, pat):
    f = re.search(pat, text)
    return f[1] if f else None


def secs(wall):
    if not wall:
        return None
    parts = [float(p) for p in wall.split(":")]
    s = 0.0
    for p in parts:
        s = s * 60 + p
    return s


def fmt(s):
    if s is None:
        return "—"
    if s < 60:
        return f"{s:.1f} s"
    s = int(round(s))
    return f"{s // 60} min {s % 60:02d} s"


def line_of(suite, name):
    for i, l in enumerate((Path("/home/qa/work/lez-programs/programs/integration_tests/tests") / f"{suite}.rs").read_text().splitlines(), 1):
        if re.match(rf"\s*fn {name}\(", l):
            return i


def stats(mode, name, base=None):
    d = base or (root / mode / name)
    log = d / "test.log"
    out = {"ran": log.exists(), "result": None, "wall": None, "rss": 0.0, "proofs": 0, "prove_wall": 0.0}
    if not log.exists():
        return out
    t = log.read_text(errors="replace")
    out["result"] = m(t, r"test result: (\w+)\. (\d+) passed")
    out["passed"] = m(t, r"test result: \w+\. (\d+) passed")
    tf = d / "test.time"
    if tf.exists():
        tt = tf.read_text()
        out["wall"] = secs(m(tt, r"Elapsed \(wall clock\) time .*?: ([\d:.]+)"))
        out["test_rss"] = float(m(tt, r"Maximum resident set size \(kbytes\): (\d+)") or 0) / 1048576
    for p in sorted(d.glob("r0vm.*.log")):
        raw = ansi.sub("", p.read_text(errors="replace"))
        r = float(m(raw, r"Maximum resident set size \(kbytes\): (\d+)") or 0) / 1048576
        out["rss"] = max(out["rss"], r)
        if "prove_session:" in raw:
            out["proofs"] += 1
            out["prove_wall"] += secs(m(raw, r"Elapsed \(wall clock\) time .*?: ([\d:.]+)")) or 0
    return out


rows, counts = [], {"Pass": 0, "Fail": 0, "Blocked": 0, "Not run": 0}
total_real = 0.0
for i, (suite, name) in enumerate(cases, 1):
    area, req, what = meta[name]
    dev, real = stats("dev", name), stats("real", name)
    ok = lambda s: s["result"] == "ok" and s.get("passed") == "1"
    if not real["ran"]:
        status = "Not run"
    elif ok(dev) and ok(real):
        status = "Pass"
    else:
        status = "Fail"
    counts[status] += 1
    total_real += real["wall"] or 0
    link = f"[`{name}`]({BLOB}/{suite}.rs#L{line_of(suite, name)})"
    rows.append((i, link, area, req, what,
                 ("Pass" if ok(dev) else "Fail") + f" · {fmt(dev['wall'])}",
                 ("Pass" if ok(real) else ("Not run" if not real["ran"] else "Fail")) + f" · {fmt(real['wall'])}",
                 f"{real['rss']:.2f} GiB" if real["rss"] else "—", str(real["proofs"]), status))

# interrupt
ilog = root / "interrupt.log"
itext = ilog.read_text(errors="replace") if ilog.exists() else ""
intr = stats(None, None, root / "interrupt" / "interrupted")
rer = stats(None, None, root / "interrupt" / "rerun")
iend = m(itext, r"END interrupted exit=(\d+)")
rend = m(itext, r"END rerun exit=(\d+)")
left = re.findall(r"r0vm left after (\w+): (\d+)", itext)
ilog_tail = (root / "interrupt" / "interrupted" / "test.log").read_text(errors="replace") if (root / "interrupt" / "interrupted" / "test.log").exists() else ""
ierr = m(ilog_tail, r"(panicked at[^\n]*\n[^\n]*)") or m(ilog_tail, r"(Error[^\n]*)") or "—"
if not itext:
    istatus, rstatus = "Not run", "Not run"
else:
    istatus = "Pass" if iend not in (None, "0") and all(n == "0" for _, n in left) else "Fail"
    rstatus = "Pass" if rend == "0" and rer["result"] == "ok" else "Fail"

extra = [
    ("interrupt", "Interrupt: stop the prover 60 s into the circuit proof of `token_mint_private_unauthorized`", "Recovery", "Reliability",
     f"exit={iend} · {fmt(float(m(itext, r'END interrupted exit=\d+ wall=([\d.]+)') or 0) or None)}", istatus),
    ("rerun", "Recovery: rerun the same case right after the interrupt", "Recovery", "Reliability",
     f"exit={rend} · {fmt(float(m(itext, r'END rerun exit=\d+ wall=([\d.]+)') or 0) or None)}", rstatus),
]
blocked = [
    ("SDK/app: deshield → swap → re-shield from a private account", "F.1, F.4, U.1, Privacy.1", "DEX-16"),
    ("SDK/app: add or remove liquidity from a private account", "F.3", "DEX-16"),
    ("SDK/app: balance covers amount and fee in one deshield; clear error if not", "U.8", "DEX-16"),
    ("App: pre-confirmation summary of what is public and private", "Privacy.2", "DEX-17"),
    ("SDK: reject a re-shield target that is not a private account", "Privacy.3", "DEX-18"),
    ("SDK: fresh ephemeral public account for every private operation", "Privacy.4", "DEX-19"),
    ("Interrupted private flow in the SDK/app leaves no funds in the ephemeral account", "U.8, Privacy.1", "DEX-16"),
]
notrun = [
    ("Swap whose output goes straight into an existing private holding (re-shield in the same transaction)", "F.4", "No test exists at this revision; the two new-holding variants are refused (rows above)."),
    ("Same private/group cases at `071375c` (the M1 re-review revision)", "—", "Not rebuilt: disk had 5.4 GB free. See finding 1."),
]
for _ in extra:
    counts[_[5]] += 1
counts["Blocked"] += len(blocked)
counts["Not run"] += len(notrun)

R = []
w = R.append
w((root / "header.md").read_text())
w("## Counts\n")
w("| Pass | Fail | Blocked | Not run | Total |\n|---:|---:|---:|---:|---:|")
w(f"| {counts['Pass']} | {counts['Fail']} | {counts['Blocked']} | {counts['Not run']} | {sum(counts.values())} |\n")
w("## Results\n")
w("Dev = `RISC0_DEV_MODE=1` (no proof). Real = `RISC0_DEV_MODE` unset, local CPU proving. Peak RSS is the largest `r0vm` process. Proofs = number of `r0vm` sessions that proved.\n")
w("| # | Case | Area | Requirement | What it checks | Dev | Real | Peak RSS | Proofs | Status |")
w("|---:|---|---|---|---|---|---|---:|---:|---|")
for r in rows:
    w("| " + " | ".join(str(x) for x in r) + " |")
n = len(rows)
for j, (_, what, area, req, real, st) in enumerate(extra, n + 1):
    w(f"| {j} | {what} | {area} | {req} | see [Recovery](#recovery) | — | {real} | — | — | {st} |")
n += len(extra)
for j, (what, req, ref) in enumerate(blocked, n + 1):
    w(f"| {j} | {what} | Client | {req} | No private path in SDK/app ({ref}, #9) | — | — | — | — | Blocked |")
n += len(blocked)
for j, (what, req, why) in enumerate(notrun, n + 1):
    w(f"| {j} | {what} | Gap | {req} | {why} | — | — | — | — | Not run |")
w("")
Path(root / "stats.txt").write_text(
    f"real_total={total_real:.0f}s\ninterrupt_exit={iend} rerun_exit={rend} left={left}\ninterrupt_err={ierr}\n"
    f"interrupt_wall={fmt(intr['wall'])} rerun_wall={fmt(rer['wall'])} rerun_rss={rer['rss']:.2f}\n")
w((root / "footer.md").read_text())
print("\n".join(R))

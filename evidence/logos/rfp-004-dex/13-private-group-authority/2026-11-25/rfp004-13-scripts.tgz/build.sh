#!/usr/bin/env bash
set -euo pipefail
source /home/qa/work/run13/environment.sh
exec >"$logs/build.log" 2>&1
date -Is
while systemctl --quiet is-active lez-rfp004-13-bootstrap.service; do sleep 10; done
df -h "$work"
git rev-parse HEAD
rustc -V; r0vm --version; cargo risczero --version; rzup show
RISC0_DEV_MODE=1 /usr/bin/time -v cargo test --locked -p integration_tests --test amm --test token --no-run --message-format=json-render-diagnostics >"$logs/build-cargo.jsonl"
date -Is
df -h "$work"

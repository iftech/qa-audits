## RFP-004 private and group-authority flows: runtime results (lez-programs@1cfaa5e)

**Summary.** All 36 private, group-authority and fresh-account integration tests for the token and AMM programs pass, in dev mode and with real proofs. This includes the two AMM cases that failed with `CircuitProvingError("rx len failed")` or hung in the [M1 re-review](https://github.com/logos-co/rfp/issues/217#issuecomment-6361006722). When we stop the prover in the middle of a proof, the test fails with the same `rx len failed` error, and the next run passes. So the old error most likely came from a prover process that died, not from the programs. The private path in the SDK and app is still missing (DEX-16 to DEX-19 in #9), so 7 client cases are Blocked. One private-swap case has no test.

With real proving, each private case takes 3 to 7 minutes and up to about 9.2 GiB of memory on a 12-vCPU CPU machine. Dev mode does not create proofs, so dev-mode results alone do not show that private flows work.

| Item | Value |
|---|---|
| Repository | [`logos-blockchain/lez-programs@1cfaa5e`](https://github.com/logos-blockchain/lez-programs/tree/1cfaa5e3446a684e6e9b61cfb243038dae6465ea) |
| LEZ | `v0.2.5-rc2` (`d8596eb734bf9c9ce801afb92df06098a2eb098a`), from `Cargo.lock` |
| RISC Zero | `risc0-zkvm` 3.0.5, `r0vm` 3.0.5, local CPU prover (`RISC0_PROVER=ipc`), no Bonsai |
| Machine | Linux 6.8 x86-64, 12 vCPU, 17 GiB RAM, 15 GiB swap |
| Date | 2026-11-25 |


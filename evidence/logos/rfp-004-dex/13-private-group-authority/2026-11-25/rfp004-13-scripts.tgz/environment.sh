work=/home/qa/work
repo=$work/lez-programs
logs=$work/run13
export HOME="$work/proving-home"
export CARGO_HOME="$work/cargo" RUSTUP_HOME="$work/rustup" CARGO_TARGET_DIR="$work/target"
export PATH="$work/bin:$CARGO_HOME/bin:$HOME/.risc0/bin:$PATH"
export TMPDIR="$work/tmp"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_NET_GIT_FETCH_WITH_CLI=true CARGO_BUILD_JOBS=4
cd "$repo"

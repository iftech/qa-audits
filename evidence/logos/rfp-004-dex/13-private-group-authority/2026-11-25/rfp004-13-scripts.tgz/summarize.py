from pathlib import Path
import re

root = Path(__file__).resolve().parent
ansi = re.compile(r"\x1b\[[0-9;]*m")
flows = [tuple(l.split()) for l in (root / "cases.txt").read_text().splitlines() if l.strip() and not l.startswith("#")]


def match(text, pattern):
    found = re.search(pattern, text)
    return found[1] if found else "—"


def elapsed(text):
    return match(text, r"Elapsed \(wall clock\) time .*?: ([\d:.]+)")


def rss(text):
    peak = match(text, r"Maximum resident set size \(kbytes\): (\d+)")
    return float(peak) / 1048576 if peak != "—" else 0


def run_stats(mode, flow):
    folder = root / mode / flow
    test_log = folder / "test.log"
    result = "not run" if not test_log.exists() else match(test_log.read_text(), r"test result: (\w+)")
    timer = folder / "test.time"
    wall = elapsed(timer.read_text()) if timer.exists() else "—"
    sessions = []
    for path in sorted(folder.glob("r0vm.*.log")):
        raw = ansi.sub("", path.read_text(errors="replace"))
        sessions.append(
            {
                "file": path.relative_to(root),
                "proof": "prove_session:" in raw,
                "wall": elapsed(raw),
                "rss": rss(raw),
                "segments": match(raw, r"number of segments: (\d+)"),
                "cycles": match(raw, r"\b(\d+) total cycles"),
                "exit": match(raw, r"Exit status: (\d+)"),
            }
        )
    return result, wall, sessions


print("| Flow | Dev result / wall | Real result / wall | Real max r0vm RSS | Real proof sessions |")
print("|---|---|---|---:|---:|")
for suite, flow in flows:
    dev, dev_wall, _ = run_stats("dev", flow)
    real, real_wall, sessions = run_stats("real", flow)
    peak = max((session["rss"] for session in sessions), default=0)
    proofs = sum(session["proof"] for session in sessions)
    peak_display = f"{peak:.2f} GiB" if peak else "—"
    print(f"| `{flow}` | {dev} / {dev_wall} | {real} / {real_wall} | {peak_display} | {proofs} |")

print()
print("| Flow | Session | Wall | Peak RSS GiB | Segments | Total cycles | Exit |")
print("|---|---|---:|---:|---:|---:|---:|")
for _, flow in flows:
    _, _, sessions = run_stats("real", flow)
    for i, session in enumerate(sessions, 1):
        if session["proof"]:
            print(
                f"| `{flow}` | [{i}]({session['file']}) | {session['wall']} | {session['rss']:.2f} "
                f"| {session['segments']} | {session['cycles']} | {session['exit']} |"
            )

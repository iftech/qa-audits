## Findings

### QA13-01: The old `rx len failed` error comes from a prover that stops

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Retired at `1cfaa5e` | Epic: historical proving failures | rows 23, 24, 37, 38 |

The two AMM cases that failed or hung at `071375c` pass with real proofs here (rows 23 and 24). When we stop `r0vm` 60 s into a proof, the test fails with the same `CircuitProvingError("rx len failed")`. The error does not say that the prover stopped, so users and testers cannot act on it; the SDK should report a clear error when this happens.

<a id="recovery"></a>
<details>
<summary>Recovery test: commands and raw output</summary>

Script: `interrupt.sh`. It runs `token_mint_private_unauthorized` with real proving. It waits until the second `r0vm` session (the circuit proof) starts, waits 60 s more, then sends `SIGTERM` to that `r0vm`. Then it runs the same case again.

```text
2026-11-25T02:41:06+00:00 START interrupted
 763534  763529      60 8902832 .../v3.0.5-cargo-risczero-x86_64-unknown-linux-gnu/r0vm --port 35703
2026-11-25T02:42:12+00:00 kill -TERM r0vm pid=763534
2026-11-25T02:42:12+00:00 END interrupted exit=101 wall=66.332607347s
r0vm left after interrupted: 0
thread 'token_mint_private_unauthorized' (763458) panicked at programs/integration_tests/tests/token.rs:915:6:
called `Result::unwrap()` on an `Err` value: CircuitProvingError("rx len failed")
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 32 filtered out; finished in 66.33s

2026-11-25T02:42:14+00:00 START rerun
2026-11-25T02:45:13+00:00 END rerun exit=0 wall=178.599307629s
r0vm left after rerun: 0
test token_mint_private_unauthorized ... ok
test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 32 filtered out; finished in 178.59s
```

The stopped `r0vm` had 8.9 GB resident memory at that moment. No `r0vm` process was left after either run. The tests keep chain state in memory, so this shows that the prover recovers. It does not show recovery of funds on a real chain; that needs the SDK path (row 45).

</details>

<details>
<summary>Why we think the M1 failures were environmental</summary>

- `071375c` and `1cfaa5e` use the same LEZ tag (`v0.2.5-rc2`) and the same `risc0-zkvm` (`=3.0.5`) in `Cargo.toml`.
- The M1 re-review ran in dev mode in a sandbox. Here dev mode passes all 36 cases too.
- A stopped prover gives exactly the M1 error. A prover that is out of memory (about 9.2 GiB needed) is one likely cause. This is an inference: we did not rebuild `071375c` (row 47).

</details>

### QA13-02: Clients still cannot run private operations

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| High | Blocked | F.1, F.3, F.4, U.1, U.8, Privacy.1–4 | rows 39–45; #9 DEX-16 to DEX-19 |

The programs accept private inputs, but the SDK and app only send public operations. Users cannot run deshield → swap → re-shield, and no client checks fees, return accounts or fresh ephemeral accounts. Add the private client path; then these 7 rows can run.

### QA13-03: No test pays a private swap into a private holding

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Medium | Not run (gap) | F.4, Privacy.3 | rows 27–30, 46 |

The private swap tests pay from a private holding into a public holding. A swap into a new private holding is refused, because the AMM requires the output holding to exist already (rows 28 and 29). Add a test where the output goes into an existing private holding, and decide whether a new private holding must work.

### QA13-04: Fresh public accounts accept tokens without a signature

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Pass (documents known behavior) | Privacy.4 (boundary) | rows 1, 3 |

Since LEZ v0.2.5, anyone can transfer or mint tokens into a fresh public account without its consent; the repository marks these tests as regression markers. So a "fresh" ephemeral account can receive history from someone else before it is used. The SDK work for Privacy.4 should check this.

### QA13-05: Real proving is slow and needs a lot of memory

| Severity | Status | Requirement | Evidence |
|---|---|---|---|
| Info | Measured | Performance (the RFP sets no proving target) | Results table |

26 of the 36 cases create real proofs. Each takes 2 min 58 s to 7 min 17 s and up to 9.17 GiB (largest `r0vm`). The whole real suite took 1 h 48 min; the dev suite took 48 s.

<details>
<summary>What stays public in a private transaction</summary>

From LEZ `d8596eb`: [`privacy_preserving_transaction/message.rs:22-31`](https://github.com/logos-blockchain/logos-execution-zone/blob/d8596eb734bf9c9ce801afb92df06098a2eb098a/lee/state_machine/src/privacy_preserving_transaction/message.rs#L22-L31) and [`core/src/circuit_io.rs:171-180`](https://github.com/logos-blockchain/logos-execution-zone/blob/d8596eb734bf9c9ce801afb92df06098a2eb098a/lee/state_machine/core/src/circuit_io.rs#L171-L180).

- **Public:** every public account the call touches, with its id and full new state (`public_actions`). In a private swap this is the config, pool, both vaults, the output holding, the tick and clock accounts and the fee holding. Vault changes show trade size and direction.
- **Public:** nonces of public signers, validity windows, program image claims.
- **Per private account:** a nullifier, the commitment root, a new commitment and the encrypted new state. The private account id and balance are not in clear text.
- In `amm_swap_a_to_b_private_user_holding` the output goes to a public holding, so the recipient is public.
- We checked this by reading code. We did not test whether nullifiers or commitments can link two operations by the same user.

</details>

<details>
<summary>Commands</summary>

```bash
# environment (environment.sh)
export HOME=/home/qa/work/proving-home CARGO_HOME=/home/qa/work/cargo RUSTUP_HOME=/home/qa/work/rustup
export CARGO_TARGET_DIR=/home/qa/work/target CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=4

# build once (build.sh): 12 min 10 s, 0.57 GiB peak
RISC0_DEV_MODE=1 cargo test --locked -p integration_tests --test amm --test token --no-run --message-format=json-render-diagnostics

# each case, one at a time (run-cases.sh dev|real)
export RISC0_PROVER=ipc RISC0_EXECUTOR=ipc RISC0_SERVER_PATH=run13/r0vm-timed.sh   # wraps r0vm in /usr/bin/time -v
export RISC0_DEV_MODE=1          # dev only; unset for real
/usr/bin/time -v -o <case>/test.time timeout --kill-after=30 1800 \
  target/debug/deps/<amm|token>-<hash> --exact <case> --nocapture --test-threads=1
```

</details>

<details>
<summary>How to reproduce</summary>

- Source: `lez-programs` `1cfaa5e3446a684e6e9b61cfb243038dae6465ea`, LEZ `v0.2.5-rc2` (`d8596eb`).
- Toolchain: Rust 1.94.0 (`rust-toolchain.toml`); `rzup` install, then `r0vm` and `cargo-risczero` 3.0.5 pinned from `Cargo.lock` (as in `.github/actions/install-risc0`); guest Rust 1.97.0, guest C++ 2024.1.5.
- Image: none (host install under one work folder, about 11.6 GB).
- Scripts in `rfp004-13-scripts.tgz`: `bootstrap.sh` → `build.sh` → `orchestrate.sh` (runs `run-cases.sh dev`, `run-cases.sh real`, `interrupt.sh`), then `make_report.py` writes this comment.
- Case list: `cases.txt` (36 cases), labels in `cases-meta.tsv`.
- Run on a newer commit: change the commit in the checkout, rerun all scripts, compare the Results table.
- Devin prompt: "Run RFP-004 private-flow tests with real proving: do the work of iftech/qa-audits#13 at logos-blockchain/lez-programs@<sha> with real (non-dev-mode) RISC0 proving; Pass / Fail / Blocked / Not run per case, timings, memory, commands and raw output."

</details>

<details>
<summary>Raw output</summary>

All logs are in `rfp004-13-raw.tgz`: `build.log`, `build-cargo.jsonl`, `dev-suite.log`, `real-suite.log`, `interrupt.log`, and per case `dev|real/<case>/test.log`, `test.time` and one `r0vm.*.log` per prover session. Example (`real/amm_swap_a_to_b_private_user_holding/test.log`):

```text
running 1 test
test amm_swap_a_to_b_private_user_holding ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 55 filtered out; finished in 302.20s
```

</details>

<details>
<summary>Limits</summary>

- These are program-level integration tests with in-memory chain state, not a sequencer or devnet.
- Only the token and AMM suites are in scope. The ATA and stablecoin group-owned tests were not run.
- One run per case; times can change with machine load.
- `071375c` was not rebuilt, so the cause of the M1 failures is an inference (QA13-01).

</details>

<details>
<summary>Glossary</summary>

- **Dev mode:** `RISC0_DEV_MODE=1`. The zkVM runs the program but makes a fake proof.
- **Real proving:** a real RISC Zero proof made on this CPU.
- **Shield / deshield:** move tokens from a public account into a private holding / from a private holding to a public account.
- **Foreign init:** create a private holding for someone else, using only their public keys.
- **Group-owned:** an account controlled by a group key that several members hold.
- **Ephemeral account:** a new temporary public account for one private operation.

</details>

## Decisions for the spec owner

1. Is the private client path (DEX-16 to DEX-19) due in milestone 1, or in a later milestone?
2. Must a private swap pay into a new private holding in one transaction, or is an existing holding the intended design?
3. Is 3 to 7 minutes and about 9.2 GiB per private operation on a CPU acceptable, or should the RFP set a proving target?

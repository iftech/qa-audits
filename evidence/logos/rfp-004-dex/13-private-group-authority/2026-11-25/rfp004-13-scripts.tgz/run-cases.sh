#!/usr/bin/env bash
# usage: run-cases.sh dev|real [cases-file] [stop-epoch]
set -uo pipefail
source /home/qa/work/run13/environment.sh
mode="${1:?pass dev or real}"; list="${2:-$logs/cases.txt}"; stop="${3:-0}"
case "$mode" in
  dev) export RISC0_DEV_MODE=1 ;;
  real) unset RISC0_DEV_MODE ;;
  *) exit 2 ;;
esac
exec >>"$logs/$mode-suite.log" 2>&1
date -Is; df -h "$work"; free -h
export RISC0_PROVER=ipc RISC0_EXECUTOR=ipc
unset BONSAI_API_URL BONSAI_API_KEY
export RISC0_INFO=1 RUST_LOG=risc0_zkvm=info,risc0_zkvm::host::server::prove::prover_impl=debug
export PROVING_R0VM="$(readlink -f "$(command -v r0vm)")"
export RISC0_SERVER_PATH="$logs/r0vm-timed.sh"
printf 'RISC0_DEV_MODE=%s\nr0vm=%s\n' "${RISC0_DEV_MODE-<unset>}" "$PROVING_R0VM"
declare -A bin
while read -r suite executable; do bin[$suite]="$executable"; done < <(python3 - "$logs/build-cargo.jsonl" <<'PY'
import json, sys
for line in open(sys.argv[1]):
    if line.startswith("{"):
        i = json.loads(line)
        if i.get("reason") == "compiler-artifact" and i["target"]["kind"] == ["test"] and i.get("executable"):
            print(i["target"]["name"], i["executable"])
PY
)
printf 'token=%s\namm=%s\n' "${bin[token]}" "${bin[amm]}"
grep -v '^#' "$list" | while read -r suite name; do
  [[ -z "$suite" ]] && continue
  if [[ "$stop" -gt 0 && "$(date +%s)" -gt "$stop" ]]; then
    printf '%s SKIP %s %s (stop time reached)\n' "$(date -Is)" "$suite" "$name"; continue
  fi
  export PROVING_RUN_DIR="$logs/$mode/$name"
  rm -rf "$PROVING_RUN_DIR"; mkdir -p "$PROVING_RUN_DIR"
  printf '%s START %s %s\n' "$(date -Is)" "$suite" "$name"
  rc=0
  /usr/bin/time -v -o "$PROVING_RUN_DIR/test.time" timeout --kill-after=30 1800 \
    "${bin[$suite]}" --exact "$name" --nocapture --test-threads=1 >"$PROVING_RUN_DIR/test.log" 2>&1 || rc=$?
  printf '%s END %s %s exit=%s\n' "$(date -Is)" "$suite" "$name" "$rc"
done
date -Is; df -h "$work"

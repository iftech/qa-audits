<details><summary>Before/after chain state and raw output excerpts</summary>

The full requests, responses and account addresses are in `logs/final-run/`. Each case has `.before/` and `.after/` directories with 31 public account records each. A case's `.tx.log` contains the exact command with public addresses; `.receipt.json` holds the full RPC result. Pool cells show reserve A, reserve B, LP supply, in that order.

### AUTH-01

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:06.653818744Z
   tx_hash: f813c65d76d56b297bf9ffbf6e7ab761a9eb45293cfefbc129b3375a4b857465
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:08.674452277Z
{"block":30}
thread '<unnamed>' panicked at /src/programs/amm/src/update_config.rs:37:5:
assertion `left == right` failed: Update config: caller is not the configured admin authority
owner-b: native balance 0 => 0; nonce 1 => 2
payer: native balance 9999939605536 => 9999923602056; nonce 25 => 26
Block 30; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### AUTH-02

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:12.528511281Z
   tx_hash: eb0a0ffd2b082a529a17f77c3cbe6720811a3af3773da8e3d8f1b82adc89f7bf
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:14.546073088Z
{"block":33}
thread '<unnamed>' panicked at src/bin/amm.rs:16:1:
account validation failed: Unauthorized { message: "Account 'authority' (index 1) must be a signer" }
payer: native balance 9999923602056 => 9999907599472; nonce 26 => 27
Missing included receipt or expected guest rejection message
Pass (rejection exercised; validation output is shown above)
~~~

### AUTH-03

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:18.476861422Z
   tx_hash: ebf77432c24ce6ab796cbfe2cecda5875468c3a5f4929436539c4d2c32017c05
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:20.496497083Z
{"block":36}
thread '<unnamed>' panicked at /src/programs/amm/src/withdraw_protocol_fees.rs:38:5:
assertion `left == right` failed: Withdraw protocol fees: caller is not the configured admin authority
owner-b: native balance 0 => 0; nonce 2 => 3
payer: native balance 9999907599472 => 9999891595608; nonce 27 => 28
Block 36; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### AUTH-04

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:24.112394432Z
   tx_hash: e7dc82f3657b77af79199a037f0df495b6692e7bfd89f7ec1010035e5b8a92c9
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:26.686619277Z
{"block":39}
thread '<unnamed>' panicked at src/bin/amm.rs:16:1:
account validation failed: Unauthorized { message: "Account 'authority' (index 3) must be a signer" }
payer: native balance 9999891595608 => 9999875592640; nonce 28 => 29
Missing included receipt or expected guest rejection message
Pass (rejection exercised; validation output is shown above)
~~~

### NS-01

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:30.932806454Z
   tx_hash: 43049e687b89cd5ac4187b62caeda6073481330541405645e21c75ce9929b166
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:32.524262459Z
{"block":42}
thread '<unnamed>' panicked at /src/programs/amm/src/withdraw_protocol_fees.rs:53:5:
assertion `left == right` failed: Withdraw protocol fees: protocol-fee holding must be owned by the configured Token Program
owner-a: native balance 0 => 0; nonce 1 => 2
payer: native balance 9999875592640 => 9999859588776; nonce 29 => 30
Missing included receipt or expected guest rejection message
Pass (rejection exercised; validation output is shown above)
~~~

### NS-02

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:36.243517410Z
   tx_hash: a3769d51f44fb733fb2c8e8b0c6a5c312b7f83f557699d34de76ceaf10633263
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:38.662991928Z
{"block":45}
thread '<unnamed>' panicked at /src/programs/amm/src/swap.rs:62:5:
assertion `left == right` failed: Swap: pool account is not derived under this config's namespace
payer: native balance 9999859588776 => 9999843583440; nonce 30 => 31
trader-a: native balance 0 => 0; nonce 6 => 7
Block 45; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### NS-03

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:42.854932907Z
   tx_hash: 304da493eeec690716ad1461f61e06fc98bf5032bdccbfa5d3b7d06e44234b3f
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:44.458535471Z
{"block":48}
thread '<unnamed>' panicked at /src/programs/amm/src/swap.rs:31:5:
assertion `left == right` failed: Vault B was not provided
payer: native balance 9999843583440 => 9999827578104; nonce 31 => 32
trader-a: native balance 0 => 0; nonce 7 => 8
Block 48; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### NS-04

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:48.291436051Z
   tx_hash: d6fdb5d762c56d1123d48091552550f5680adc8a52d7f0606b3a4a49fbac470c
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:50.458556791Z
{"block":51}
thread '<unnamed>' panicked at /src/programs/amm/src/swap.rs:226:5:
assertion `left == right` failed: Swap exact input: protocol-fee holding does not match the input token's protocol PDA
payer: native balance 9999827578104 => 9999811572768; nonce 32 => 33
trader-a: native balance 0 => 0; nonce 8 => 9
Block 51; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### NS-05

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:53.689630670Z
   tx_hash: 59193ac1971bb7f80867de4ffe1ac3cc1223ddbf11414a3250d66a9454604328
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:53:54.703661114Z
{"block":53}
thread '<unnamed>' panicked at /src/programs/amm/src/swap.rs:237:5:
assertion `left == right` failed: Swap exact input: current tick Account ID does not match PDA
payer: native balance 9999811572768 => 9999795567432; nonce 33 => 34
trader-a: native balance 0 => 0; nonce 9 => 10
Block 53; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### ROLL-01

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | Not initialized | Not initialized |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:52:54.576346593Z
   tx_hash: c0acbfdd9f454a1f60f66c076782fc3ecbcd8195c739ede71dd3ea334afab64c
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:52:57.158181669Z
{"block":24}
thread '<unnamed>' panicked at /src/programs/token/src/transfer.rs:42:18:
Insufficient balance
payer: native balance 9999987755712 => 9999971748072; nonce 21 => 22
trader-a: native balance 0 => 0; nonce 3 => 4
trader-b: native balance 0 => 0; nonce 2 => 3
trader-lp-b: native balance 0 => 0; nonce 0 => 1
Block 24; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### ROLL-02

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 109993, 181868, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 109993 |
| pool-a.vault-b | 181868 | 181868 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 7 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 890000 | 890000 |
| trader-b | 818132 | 818132 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | Not initialized | Not initialized |
| other-trader-b | Not initialized | Not initialized |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:53:58.328864121Z
   tx_hash: e47a7df0299d99a2411799a08a2e23fb79e9dc61c62577506542fd63cce85053
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:54:00.774109839Z
{"block":56}
thread '<unnamed>' panicked at /src/programs/token/src/transfer.rs:23:5:
assertion `left == right` failed: Sender and recipient definition id mismatch
payer: native balance 9999795567432 => 9999779562096; nonce 34 => 35
trader-a: native balance 0 => 0; nonce 10 => 11
Block 56; AMM/token state unchanged; only expected fee/nonce effects remain.
Pass
~~~

### CONC-01

| Account | Before | After |
| --- | ---: | ---: |
| pool-a | 109993, 181868, 141421 | 131977, 151634, 141421 |
| pool-b | Not initialized | Not initialized |
| pool-a.vault-a | 109993 | 131977 |
| pool-a.vault-b | 181868 | 151634 |
| pool-b.vault-a | Not initialized | Not initialized |
| pool-b.vault-b | Not initialized | Not initialized |
| namespace-a.fee-a | 7 | 23 |
| namespace-a.fee-b | Not initialized | Not initialized |
| namespace-b.fee-a | Not initialized | Not initialized |
| namespace-b.fee-b | Not initialized | Not initialized |
| trader-a | 865000 | 855000 |
| trader-b | 818131 | 830524 |
| trader-c | 1000000 | 1000000 |
| trader-lp-a | 140421 | 140421 |
| trader-lp-b | Not initialized | Not initialized |
| pool-a.lp-lock | 1000 | 1000 |
| pool-b.lp-lock | Not initialized | Not initialized |
| other-trader-a | 25000 | 13000 |
| other-trader-b | 1 | 17842 |

Raw output excerpts:

~~~text
Start UTC: 2026-11-24T23:54:10.566346361Z
   tx_hash: 1dd0b1b6f5f95387a3ecbf15558bcdfbe01788ea461c2973a73ec08d14b48fe1
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:54:14.979484373Z
{"block":62}
Start UTC: 2026-11-24T23:54:10.567413622Z
   tx_hash: 95a4ccbcd33541127b4e67cab5e264c5f386af61d0522fae11beecb54bba9b93
✅ Transaction confirmed — included in a block.
End UTC: 2026-11-24T23:54:14.978924522Z
{"block":62}
Receipt blocks: [62, 62]
Pool [LP supply, reserve A, reserve B]: (141421, 109993, 181868) => (141421, 131977, 151634)
pool-a.vault-a: 109993 => 131977 (delta: +21984)
pool-a.vault-b: 181868 => 151634 (delta: -30234)
namespace-a.fee-a: 7 => 23 (delta: +16)
trader-a: 865000 => 855000 (delta: -10000)
trader-b: 818131 => 830524 (delta: +12393)
other-trader-a: 25000 => 13000 (delta: -12000)
other-trader-b: 1 => 17842 (delta: +17841)
Matches serial accounting in submission-label order: [2, 1]
Pass
~~~

</details>


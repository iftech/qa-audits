import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
cases = ("AUTH-01", "AUTH-02", "AUTH-03", "AUTH-04", "NS-01", "NS-02", "NS-03",
         "NS-04", "NS-05", "ROLL-01", "ROLL-02", "CONC-01")
holdings = ("pool-a.vault-a", "pool-a.vault-b", "pool-b.vault-a", "pool-b.vault-b",
            "namespace-a.fee-a", "namespace-a.fee-b", "namespace-b.fee-a", "namespace-b.fee-b",
            "trader-a", "trader-b", "trader-c", "trader-lp-a", "trader-lp-b",
            "pool-a.lp-lock", "pool-b.lp-lock", "other-trader-a", "other-trader-b")


def read_accounts(folder):
    return {p.stem: json.loads(p.read_text())["result"] for p in folder.glob("*.json")}


def value(name, account):
    data = bytes(account["data"])
    if not data:
        return "Not initialized"
    if name in holdings:
        assert data[0] == 0 and len(data) == 49
        return str(int.from_bytes(data[33:], "little"))
    assert len(data) == 208
    return ", ".join(str(int.from_bytes(data[i:i+16], "little")) for i in (176, 192, 160))


print("<details><summary>Before/after chain state and raw output excerpts</summary>\n")
print("The full requests, responses and account addresses are in "
      "\`logs/final-run/\`. Each case has \`.before/\` and \`.after/\` directories with "
      "31 public account records each. A case's \`.tx.log\` contains the exact command "
      "with public addresses; \`.receipt.json\` holds the full RPC result. "
      "Pool cells show reserve A, reserve B, LP supply, in that order.\n".replace("\\", ""))
for case in cases:
    before, after = (read_accounts(root / f"{case}.{phase}") for phase in ("before", "after"))
    if not before or not after:
        continue
    print(f"### {case}\n")
    print("| Account | Before | After |\n| --- | ---: | ---: |")
    for name in ("pool-a", "pool-b", *holdings):
        x, y = value(name, before[name]), value(name, after[name])
        print(f"| {name} | {x} | {y} |")
    print()
    labels = ("CONC-01.first", "CONC-01.second") if case == "CONC-01" else (case,)
    print("Raw output excerpts:\n")
    print("~~~text")
    for label in labels:
        text = (root / f"{label}.tx.log").read_text()
        for line in text.splitlines():
            if re.search(r"^Start UTC:|^End UTC:|^   tx_hash:|Transaction confirmed|NOT confirmed|^\{\"block\":|^\{\"jsonrpc\":", line):
                print(line)
    seq = root / f"{case}.sequencer.log"
    lines = seq.read_text().splitlines()
    for i, line in enumerate(lines):
        if "panicked at " in line:
            print(line)
            print(lines[i + 1])
            break
    check = root / ("concurrency.check.log" if case == "CONC-01" else f"{case}.state-check.log")
    check_text = check.read_text().rstrip()
    if check_text.endswith("Blocked"):
        check_text = check_text[:-len("Blocked")] + "Pass (rejection exercised; validation output is shown above)"
    print(check_text)
    print("~~~\n")
print("</details>\n")

#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT=$(realpath "$1")
BASE=$(realpath "$2")
OUT=$(realpath -m "$3")
SCRIPT_DIR=$(dirname "$(realpath "${BASH_SOURCE[0]}")")
URL="http://127.0.0.1:${PORT:-3040}"
[[ ! -e "$OUT" ]]
mkdir -p "$OUT"
export LEE_WALLET_HOME_DIR="$BASE/wallet" RISC0_DEV_MODE=1 RUST_LOG=warn
export RISC0_SERVER_PATH="$(command -v r0vm)"
exec > >(tee "$OUT/run.log") 2>&1
WALLET="$ROOT/logos-execution-zone/target/release/wallet"
SPEL="$ROOT/spel/target/release/spel"
PDAS="$ROOT/lez-programs/target/debug/examples/amm_pdas"
cd "$ROOT/lez-programs"
AMM_IDL=artifacts/amm-idl.json
TOKEN_IDL=artifacts/token-idl.json
TWAP_IDL=artifacts/twap_oracle-idl.json
[[ $(git rev-parse HEAD) == 1cfaa5e3446a684e6e9b61cfb243038dae6465ea ]]
[[ $(git -C "$ROOT/logos-execution-zone" rev-parse HEAD) == d8596eb734bf9c9ce801afb92df06098a2eb098a ]]
[[ $(git -C "$ROOT/spel" rev-parse HEAD) == c6f73ce21e4805f8430f03afdbdedf0b7e479a5e ]]
[[ $("$RISC0_SERVER_PATH" --version) == 'risc0-r0vm 3.0.5' ]]
rg -q '^PASS: public pool create' "$BASE/public-smoke.log"
[[ $(jq -r '.sequencers[0].sequencer_addr' "$LEE_WALLET_HOME_DIR/wallet_config.json") == "$URL" ]]

log_cmd() { printf '$'; printf ' %q' "$@"; printf '\n'; }
run() { log_cmd "$@"; "$@"; }
rpc() {
    local method=$1 params=${2:-'[]'}
    curl -fsS --max-time 5 -H 'Content-Type: application/json' --data \
        "$(jq -nc --arg method "$method" --argjson params "$params" \
            '{jsonrpc:"2.0",id:1,method:$method,params:$params}')" "$URL"
    printf '\n'
}
from_smoke() { awk -v prefix="$1" 'index($0,prefix)==1 {print $NF}' "$BASE/public-smoke.log"; }
id() { "$WALLET" account id --account-id "$1" | sed -n '1p'; }
pda() { awk -v key="$2" '$1 == key {print $2}' "$1"; }
run rpc checkHealth | tee "$OUT/health.json"
tail -n 1 "$OUT/health.json" | jq -e 'has("result")' >/dev/null
AMM=$(from_smoke 'amm program header:')
TOKEN=$(from_smoke 'token program header:')
TWAP=$(from_smoke 'twap_oracle program header:')
PAYER=$(from_smoke 'Imported pinned SPEL debug-genesis fee payer:')
OWNER=$(id namespace-owner)
DEF_A=$(id definition-a); DEF_B=$(id definition-b)
HOLD_A=$(id holding-a); HOLD_B=$(id holding-b); HOLD_LP=$(id holding-lp)
NONCE=$(printf '%064d' 0)
CLOCK=4BdcjoXkq786TMWcBGGHqcxeLYMZmn17rL4eM9ZyRWNU
DEADLINE=18446744073709551615
for label in qa12-owner-b qa12-lp-b qa12-input qa12-output qa12-third-def qa12-third-holding; do
    run "$WALLET" account new public --label "$label"
done
OWNER2=$(id qa12-owner-b); HOLD_LP2=$(id qa12-lp-b)
INPUT2=$(id qa12-input); OUTPUT2=$(id qa12-output)
DEF_C=$(id qa12-third-def); HOLD_C=$(id qa12-third-holding)
run "$PDAS" "$AMM" "$OWNER" "$TWAP" "$DEF_A" "$DEF_B" | tee "$OUT/pdas-a.txt"
run "$PDAS" "$AMM" "$OWNER2" "$TWAP" "$DEF_A" "$DEF_B" | tee "$OUT/pdas-b.txt"
CONFIG=$(pda "$OUT/pdas-a.txt" config); CONFIG2=$(pda "$OUT/pdas-b.txt" config)
POOL=$(pda "$OUT/pdas-a.txt" pool); POOL2=$(pda "$OUT/pdas-b.txt" pool)
VA=$(pda "$OUT/pdas-a.txt" vault_a); VA2=$(pda "$OUT/pdas-b.txt" vault_a)
VB=$(pda "$OUT/pdas-a.txt" vault_b); VB2=$(pda "$OUT/pdas-b.txt" vault_b)
LP=$(pda "$OUT/pdas-a.txt" pool_definition_lp); LP2=$(pda "$OUT/pdas-b.txt" pool_definition_lp)
LOCK=$(pda "$OUT/pdas-a.txt" lp_lock_holding); LOCK2=$(pda "$OUT/pdas-b.txt" lp_lock_holding)
TICK=$(pda "$OUT/pdas-a.txt" current_tick_account); TICK2=$(pda "$OUT/pdas-b.txt" current_tick_account)
FA=$(pda "$OUT/pdas-a.txt" protocol_fee_a); FA2=$(pda "$OUT/pdas-b.txt" protocol_fee_a)
FB=$(pda "$OUT/pdas-a.txt" protocol_fee_b); FB2=$(pda "$OUT/pdas-b.txt" protocol_fee_b)

declare -A accounts=(
    [config-a]="$CONFIG" [config-b]="$CONFIG2" [owner-a]="$OWNER" [owner-b]="$OWNER2"
    [pool-a]="$POOL" [pool-b]="$POOL2" [pool-a.vault-a]="$VA" [pool-a.vault-b]="$VB"
    [pool-b.vault-a]="$VA2" [pool-b.vault-b]="$VB2" [pool-a.tick]="$TICK" [pool-b.tick]="$TICK2"
    [pool-a.lp-def]="$LP" [pool-b.lp-def]="$LP2" [pool-a.lp-lock]="$LOCK" [pool-b.lp-lock]="$LOCK2"
    [namespace-a.fee-a]="$FA" [namespace-a.fee-b]="$FB" [namespace-b.fee-a]="$FA2" [namespace-b.fee-b]="$FB2"
    [trader-a]="$HOLD_A" [trader-b]="$HOLD_B" [trader-c]="$HOLD_C" [trader-lp-a]="$HOLD_LP"
    [trader-lp-b]="$HOLD_LP2" [other-trader-a]="$INPUT2" [other-trader-b]="$OUTPUT2"
    [def-a]="$DEF_A" [def-b]="$DEF_B" [def-c]="$DEF_C" [payer]="$PAYER"
)
for key in "${!accounts[@]}"; do
    [[ ${accounts[$key]} =~ ^[1-9A-HJ-NP-Za-km-z]{32,44}$ ]]
    printf '%s\t%s\n' "$key" "${accounts[$key]}"
done | sort | tee "$OUT/accounts.tsv"

snapshot() {
    local folder="$OUT/$1" key address
    mkdir -p "$folder"
    while IFS=$'\t' read -r key address; do
        log_cmd rpc getAccount "[\"$address\"]"
        rpc getAccount "[\"$address\"]" > "$folder/$key.json"
        jq -e '.result | type == "object"' "$folder/$key.json" >/dev/null
    done < "$OUT/accounts.tsv"
}
submit() {
    local label=$1 idl=$2 program=$3 payer=$4 rc=0 hash
    shift 4
    (
        printf 'Start UTC: %s\n' "$(date -u +%FT%T.%NZ)"
        log_cmd timeout 24 "$SPEL" --idl "$idl" --program "$program" --fee-payer "$payer" -- "$@"
        timeout 24 "$SPEL" --idl "$idl" --program "$program" --fee-payer "$payer" -- "$@" || rc=$?
        printf 'Exit: %s\nEnd UTC: %s\n' "$rc" "$(date -u +%FT%T.%NZ)"
        hash=$(awk '/tx_hash:/ {print $2}' "$OUT/$label.tx.log")
        if [[ $hash =~ ^[0-9a-f]{64}$ ]]; then
            log_cmd rpc getTransaction "[\"$hash\"]"
            rpc getTransaction "[\"$hash\"]" > "$OUT/$label.receipt.json"
            jq -c 'if .result == null then . else {block: .result[1]} end' "$OUT/$label.receipt.json"
        fi
    ) > "$OUT/$label.tx.log" 2>&1
}
accepted() { jq -e '.result | type == "array"' "$OUT/$1.receipt.json" >/dev/null; }
case_result() { printf '%s\t%s\n' "$1" "$2" | tee -a "$OUT/results.tsv"; }
reject() {
    local label=$1 expected=$2 idl=$3 nonce_signers=$4
    shift 4
    local start diff_file="$OUT/$label.diff"
    snapshot "$label.before"
    start=$(wc -l < "$BASE/sequencer.log")
    submit "$label" "$idl" "$AMM" "$PAYER" "$@"
    tail -n "+$((start+1))" "$BASE/sequencer.log" > "$OUT/$label.sequencer.log"
    snapshot "$label.after"
    cat "$OUT/$label.tx.log"
    python3 "$SCRIPT_DIR/check-state.py" "$OUT" "$label" "$expected" "$nonce_signers" "$diff_file" |
        tee "$OUT/$label.state-check.log"
    case_result "$label" "$(tail -n 1 "$OUT/$label.state-check.log")"
}
init_b=(initialize --owner "$OWNER2" --config "$CONFIG2" --nonce "$NONCE"
    --token-program-id "$TOKEN" --twap-oracle-program-id "$TWAP" --authority "$OWNER2"
    --swap-fee-bps 30 --protocol-fee-bps 2500)
create_b=(new-definition --config "$CONFIG2" --pool "$POOL2" --vault-a "$VA2" --vault-b "$VB2"
    --pool-definition-lp "$LP2" --lp-lock-holding "$LOCK2" --user-holding-a "$HOLD_A"
    --user-holding-b "$HOLD_B" --user-holding-lp "$HOLD_LP2" --current-tick-account "$TICK2"
    --clock "$CLOCK" --token-b-amount 200000 --deadline "$DEADLINE")
swap() {
    local config=$1 pool=$2 va=$3 vb=$4 input=$5 output=$6 tick=$7 fee=$8 gross=$9
    swap_args=(swap-exact-input --config "$config" --pool "$pool" --vault-a "$va" --vault-b "$vb"
        --user-input-holding "$input" --user-output-holding "$output" --current-tick-account "$tick"
        --clock "$CLOCK" --protocol-fee-holding "$fee" --swap-amount-in "$gross"
        --min-amount-out 1 --deadline "$DEADLINE")
}

submit init-b "$AMM_IDL" "$AMM" "$PAYER" "${init_b[@]}"
accepted init-b
reject ROLL-01 'Insufficient balance' "$AMM_IDL" trader-a,trader-b,trader-lp-b "${create_b[@]}" --token-a-amount 2000000
submit create-b "$AMM_IDL" "$AMM" "$PAYER" "${create_b[@]}" --token-a-amount 100000
accepted create-b
swap "$CONFIG2" "$POOL2" "$VA2" "$VB2" "$HOLD_A" "$HOLD_B" "$TICK2" "$FA2" 10000
submit accrue-b "$AMM_IDL" "$AMM" "$PAYER" "${swap_args[@]}"
accepted accrue-b
submit token-c "$TOKEN_IDL" "$TOKEN" "$PAYER" new-fungible-definition --name 'QA Token C' \
    --total-supply 1000000 --mint-authority none --definition-target-account "$DEF_C" --holding-target-account "$HOLD_C"
accepted token-c

unsigned_idl="$OUT/amm-unsigned-authority.json"
log_cmd jq 'set authority signer:false for UpdateConfig and WithdrawProtocolFees' "$AMM_IDL"
jq '(.instructions[] | select(.name == "update_config" or .name == "withdraw_protocol_fees")
    | .accounts[] | select(.name == "authority") | .signer) = false' "$AMM_IDL" > "$unsigned_idl"
reject AUTH-01 'Update config: caller is not the configured admin authority' "$AMM_IDL" owner-b \
    update-config --config "$CONFIG" --authority "$OWNER2" --new-authority "$OWNER2"
reject AUTH-02 'Update config: admin authority must authorize the update' "$unsigned_idl" '' \
    update-config --config "$CONFIG" --authority "$OWNER" --new-authority "$OWNER2"
withdraw=(withdraw-protocol-fees --config "$CONFIG" --destination "$HOLD_A" --amount 1)
reject AUTH-03 'Withdraw protocol fees: caller is not the configured admin authority' "$AMM_IDL" owner-b \
    "${withdraw[@]}" --authority "$OWNER2" --protocol-fee-holding "$FA"
reject AUTH-04 'Withdraw protocol fees: admin authority must authorize the withdrawal' "$unsigned_idl" '' \
    "${withdraw[@]}" --authority "$OWNER" --protocol-fee-holding "$FA"
reject NS-01 'Withdraw protocol fees: holding does not match the protocol-fee PDA' "$AMM_IDL" owner-a \
    "${withdraw[@]}" --authority "$OWNER" --protocol-fee-holding "$FA2"
swap "$CONFIG2" "$POOL" "$VA" "$VB" "$HOLD_A" "$HOLD_B" "$TICK" "$FA2" 10000
reject NS-02 "pool account is not derived under this config's namespace" "$AMM_IDL" trader-a "${swap_args[@]}"
swap "$CONFIG" "$POOL" "$VA" "$VB2" "$HOLD_A" "$HOLD_B" "$TICK" "$FA" 10000
reject NS-03 'Vault B was not provided' "$AMM_IDL" trader-a "${swap_args[@]}"
swap "$CONFIG" "$POOL" "$VA" "$VB" "$HOLD_A" "$HOLD_B" "$TICK" "$FA2" 10000
reject NS-04 "protocol-fee holding does not match the input token's protocol PDA" "$AMM_IDL" trader-a "${swap_args[@]}"
swap "$CONFIG" "$POOL" "$VA" "$VB" "$HOLD_A" "$HOLD_B" "$TICK2" "$FA" 10000
reject NS-05 'current tick Account ID does not match PDA' "$AMM_IDL" trader-a "${swap_args[@]}"
swap "$CONFIG" "$POOL" "$VA" "$VB" "$HOLD_A" "$HOLD_C" "$TICK" "$FA" 10000
reject ROLL-02 'Sender and recipient definition id mismatch' "$AMM_IDL" trader-a "${swap_args[@]}"

submit fund-input "$TOKEN_IDL" "$TOKEN" "$PAYER" transfer --sender "$HOLD_A" --recipient "$INPUT2" --amount-to-transfer 25000
accepted fund-input
submit fund-output "$TOKEN_IDL" "$TOKEN" "$PAYER" transfer --sender "$HOLD_B" --recipient "$OUTPUT2" --amount-to-transfer 1
accepted fund-output
run "$WALLET" auth-transfer send --from "Public/$PAYER" --to "Public/$OWNER2" --amount 1000000000

snapshot CONC-01.before
start=$(wc -l < "$BASE/sequencer.log")
swap "$CONFIG" "$POOL" "$VA" "$VB" "$HOLD_A" "$HOLD_B" "$TICK" "$FA" 10000
submit CONC-01.first "$AMM_IDL" "$AMM" "$PAYER" "${swap_args[@]}" &
first=$!
swap "$CONFIG" "$POOL" "$VA" "$VB" "$INPUT2" "$OUTPUT2" "$TICK" "$FA" 12000
submit CONC-01.second "$AMM_IDL" "$AMM" "$OWNER2" "${swap_args[@]}" &
second=$!
wait "$first"; wait "$second"
tail -n "+$((start+1))" "$BASE/sequencer.log" > "$OUT/CONC-01.sequencer.log"
snapshot CONC-01.after
cat "$OUT"/CONC-01.{first,second}.tx.log
python3 "$SCRIPT_DIR/check-concurrency.py" "$OUT" | tee "$OUT/concurrency.check.log"
case_result CONC-01 "$(tail -n 1 "$OUT/concurrency.check.log")"

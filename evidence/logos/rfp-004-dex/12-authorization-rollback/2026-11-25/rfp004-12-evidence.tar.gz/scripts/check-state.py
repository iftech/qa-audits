import json
from pathlib import Path
import sys

root, case, expected, signers, diff = sys.argv[1:]
root, diff = Path(root), Path(diff)
before, after = root / f"{case}.before", root / f"{case}.after"
signers = {"payer", *filter(None, signers.split(","))}


def read(path):
    return json.loads(path.read_text())["result"]


receipt = root / f"{case}.receipt.json"
receipt = read(receipt) if receipt.exists() else None
errors = []
assert {p.name for p in before.iterdir()} == {p.name for p in after.iterdir()}
for source in sorted(before.glob("*.json")):
    left, right = read(source), read(after / source.name)
    name = source.stem
    for field in ("program_owner", "data"):
        if left[field] != right[field]:
            errors.append(f"{name}: {field} changed")
    native_delta = right["balance"] - left["balance"]
    nonce_delta = right["nonce"] - left["nonce"]
    if native_delta or nonce_delta:
        print(f"{name}: native balance {left['balance']} => {right['balance']}; "
              f"nonce {left['nonce']} => {right['nonce']}")
    if native_delta >= 0 if receipt and name == "payer" else native_delta != 0:
        errors.append(f"{name}: unexpected native balance delta {native_delta}")
    if nonce_delta != int(bool(receipt) and name in signers):
        errors.append(f"{name}: unexpected nonce delta {nonce_delta}")

diff.write_text("".join(f"{line}\n" for line in errors))
if errors:
    print(*errors, sep="\n")
    print("Fail")
elif not receipt or expected not in (root / f"{case}.sequencer.log").read_text():
    print("Missing included receipt or expected guest rejection message")
    print("Blocked")
else:
    print(f"Block {receipt[1]}; AMM/token state unchanged; only expected fee/nonce effects remain.")
    print("Pass")

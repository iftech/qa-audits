import itertools
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
before = root / "CONC-01.before"
after = root / "CONC-01.after"


def read(path):
    return json.loads(path.read_text())["result"]


def data(folder, name):
    return bytes(read(folder / f"{name}.json")["data"])


def holding(folder, name):
    raw = data(folder, name)
    assert len(raw) == 49 and raw[0] == 0, (name, raw.hex())
    return int.from_bytes(raw[-16:], "little")


def pool(folder):
    raw = data(folder, "pool-a")
    assert len(raw) == 208, (len(raw), raw.hex())
    return tuple(int.from_bytes(raw[i:i+16], "little") for i in range(160, 208, 16))


def evaluate():
    receipts = [read(root / f"CONC-01.{name}.receipt.json")
                if (root / f"CONC-01.{name}.receipt.json").exists() else None
                for name in ("first", "second")]
    blocks = [r[1] if r else None for r in receipts]
    print("Receipt blocks:", blocks)
    opening_lp, opening_a, opening_b = pool(before)
    closing_lp, closing_a, closing_b = pool(after)
    names = ("pool-a.vault-a", "pool-a.vault-b", "namespace-a.fee-a",
             "trader-a", "trader-b", "other-trader-a", "other-trader-b")
    opening = [holding(before, n) for n in names]
    closing = [holding(after, n) for n in names]
    print("Pool [LP supply, reserve A, reserve B]:", pool(before), "=>", pool(after))
    for n, x, y in zip(names, opening, closing, strict=True):
        print(f"{n}: {x} => {y} (delta: {y-x:+})")
    assert opening[:2] == [opening_a, opening_b], "opening vault/reserve mismatch"
    assert closing[:2] == [closing_a, closing_b], "closing vault/reserve mismatch"
    assert closing_lp == opening_lp, "LP supply changed"
    assert sum(opening[i] for i in [0, 2, 3, 5]) == sum(closing[i] for i in [0, 2, 3, 5]), "A not conserved"
    assert sum(opening[i] for i in [1, 4, 6]) == sum(closing[i] for i in [1, 4, 6]), "B not conserved"
    changed_allowed = {f"{n}.json" for n in names} | {"pool-a.json", "pool-a.tick.json", "owner-b.json", "payer.json"}
    for p in before.glob("*.json"):
        assert p.name in changed_allowed or p.read_bytes() == (after / p.name).read_bytes(), p.name
    settled = [i for i, r in enumerate(receipts) if r]
    for order in itertools.permutations(settled):
        if tuple(blocks[i] for i in order) != tuple(sorted(blocks[i] for i in order)):
            continue
        expected = opening.copy()
        for i in order:
            gross = (10000, 12000)[i]
            effective = gross * 9970 // 10000
            protocol = (gross - effective) * 2500 // 10000
            out = expected[1] * effective // (expected[0] + effective)
            expected[0] += gross - protocol
            expected[1] -= out
            expected[2] += protocol
            expected[3 + i * 2] -= gross
            expected[4 + i * 2] += out
        if expected == closing:
            print("Matches serial accounting in submission-label order:", [i + 1 for i in order])
            return "Pass" if len(settled) == 2 and blocks[0] == blocks[1] else "Blocked"
    return "Fail"


try:
    print(evaluate())
except (AttributeError, AssertionError, FileNotFoundError, KeyError, TypeError, ValueError) as e:
    print(f"Check error: {e!r}")
    print("Blocked")

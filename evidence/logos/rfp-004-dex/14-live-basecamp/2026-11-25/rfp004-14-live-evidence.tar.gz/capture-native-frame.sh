#!/usr/bin/env bash
set -euo pipefail
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
label=${1:?usage: capture-native-frame.sh label}
[[ $label =~ ^[a-zA-Z0-9.-]+$ ]]
test -s "$W/basecamp-journey.log"
export DISPLAY=":$(<"$W/basecamp-display")"
window=$(xdotool search --name '^Logos Basecamp$' | head -1)
mkdir -p "$E/screenshots"
import -window "$window" "$E/screenshots/$label.png"
date -Is
identify "$E/screenshots/$label.png"

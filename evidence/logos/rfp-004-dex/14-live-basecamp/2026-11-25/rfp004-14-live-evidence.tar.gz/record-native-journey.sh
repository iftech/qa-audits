#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
test -s "$W/basecamp-journey.log"
export DISPLAY=":$(<"$W/basecamp-display")"
export GST_REGISTRY="$W/gstreamer-registry.bin"
xdotool search --onlyvisible --name '^Logos Basecamp$' >/dev/null
exec gst-launch-1.0 -q -e \
    ximagesrc use-damage=false show-pointer=true \
    '!' video/x-raw,framerate=12/1 \
    '!' videoconvert \
    '!' vp8enc deadline=1 cpu-used=8 target-bitrate=1400000 \
    '!' webmmux \
    '!' filesink location="$E/native-journey.webm"

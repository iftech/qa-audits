#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
cd "$W"
exec >"$E/build-tools.log" 2>&1
test -x "$W/bin/sequencer_service"
test -x "$W/bin/wallet"

export HOME="$W/home" TMPDIR="$W/tmp" CARGO_HOME="$W/cargo" RUSTUP_HOME="$W/rustup"
export XDG_CACHE_HOME="$W/cache" XDG_STATE_HOME="$W/state" XDG_CONFIG_HOME="$W/config"
export PATH="$W/bin:$CARGO_HOME/bin:$HOME/.risc0/bin:/nix/store/r9941n32g4wyvggz2703dlplbdq8a6rd-cmake-4.1.2/bin:/nix/store/armsfbcsbzax7pnkim9cqgkx8n747n31-protobuf-34.1/bin:/nix/store/4my6a75b8p1w734w7crqfw69jw7xarla-pkg-config-0.29.2/bin:/usr/local/bin:/usr/bin:/bin"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_RELEASE_STRIP=debuginfo
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_NET_GIT_FETCH_WITH_CLI=true CARGO_BUILD_JOBS=4
export GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
export RECURSION_SRC_PATH="$W/744b999f0a35b3c86753311c7efb2a0054be21727095cf105af6ee7d3f4d8849.zip"
source "$W/native-deps.env"

guard() {
    while :; do
        avail=$(df -B1 --output=avail "$W" | tail -1)
        printf '%s %s\n' "$(date -Is)" "$avail" >>"$E/disk-samples.txt"
        if (( avail < 3500000000 )); then
            echo "Disk guard: ${avail} bytes remaining; stopping build service." >&2
            systemctl --user stop --no-block rfp004-ui-tools.service || kill -TERM "$1"
            return
        fi
        sleep 2
    done
}
guard "$$" &
guard_pid=$!
trap 'kill "$guard_pid" 2>/dev/null || true' EXIT

export CARGO_TARGET_DIR="$W/target"
cd "$W/spel"
echo "Building locked SPEL CLI"
/usr/bin/time -v cargo +1.94.0 build --locked --release -p spel
install -m755 "$CARGO_TARGET_DIR/release/spel" "$W/bin/"
cd "$W/lez-programs"
echo "Building locked AMM PDA helper"
# Host-only calculator; the real guests are built separately in the pinned
# container. Reuse the release profile to avoid a duplicate target tree.
RISC0_SKIP_BUILD=1 /usr/bin/time -v cargo +1.94.0 build --locked --release -p amm_program --example amm_pdas
install -m755 "$CARGO_TARGET_DIR/release/examples/amm_pdas" "$W/bin/"
sha256sum "$W/bin/"{spel,amm_pdas}
printf 'SPEL %s @ %s\n' \
  "$(sed -n 's/^version = "\(.*\)"/\1/p' "$W/spel/spel-cli/Cargo.toml" | head -1)" \
  "$(git -C "$W/spel" rev-parse HEAD)"
df -B1 "$W"

#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
exec >>"$E/serial-builds.log" 2>&1
cd "$W"
date -Is

# No parallel builds: wait for the existing chain unit. The package command
# is not a cheap dry run: the locked evaluation performs IFD at this revision.
while systemctl --user is-active --quiet rfp004-ui-chain.service; do sleep 5; done
test -x "$W/bin/sequencer_service"
test -x "$W/bin/wallet"
df -B1 "$W"
systemd-run --user --wait --unit rfp004-ui-tools -p RuntimeMaxSec=50m -p Nice=10 \
    /bin/bash "$E/build-tools.sh"
test -x "$W/bin/spel"
test -x "$W/bin/amm_pdas"
printf '%s\n' 'Deleting this run’s Cargo target after installing and hashing its executables:'
du -s -B1 "$W/target"
rm -rf -- "$W/target"
df -B1 "$W"
systemd-run --user --wait --unit rfp004-ui-guests -p RuntimeMaxSec=50m -p Nice=10 \
    /bin/bash "$E/build-guests-isolated.sh"
for guest in token twap_oracle amm; do test -s "$W/lez-programs/target/guest/$guest.bin"; done
! sudo -n systemctl is-active --quiet rfp004-ui-guest-docker.service
printf '%s\n' 'Deleting this run’s isolated Docker data after validating guest ImageIDs:'
sudo -n du -s -B1 "$W/docker-data"
sudo -n rm -rf -- "$W/docker-data" "$W/docker-exec"
df -B1 "$W"
sudo -n systemd-run --wait --unit rfp004-ui-packages --uid qa --gid qa \
    -p RuntimeMaxSec=60m -p Nice=10 --setenv=PATH="$PATH" --setenv=PACKAGE_MODE=build \
    /bin/bash "$E/build-native-packages.sh"
for module in amm_ui amm_module lez_core; do
    compgen -G "$W/packages/logos-$module-module*.lgx" >/dev/null
done
date -Is
df -B1 "$W"

#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
export PATH="$W/bin:$W/cargo/bin:$W/home/.risc0/bin:$PATH"
export CARGO_HOME="$W/cargo" RUSTUP_HOME="$W/rustup" HOME="$W/home"
export PORT=3040 RUN_PARENT="$W" KEEP_SEQUENCER=1
cd "$W"

if [[ ${1:-} == resume ]]; then
    R=$(<"$W/run-dir")
    [[ $R == "$W"/rfp004-smoke.* ]]
    if [[ ! -d $R/chain && -s $R/chain-offline.tar.gz ]]; then
        tar -xzf "$R/chain-offline.tar.gz" -C "$R"
    fi
    test -d "$R/chain"
    source "$W/basecamp-runtime.env"
    export RUST_LOG=info,kameo=warn
    exec "$W/bin/sequencer_service" "$R/sequencer.json" --home "$R/chain" \
        --listen-address 127.0.0.1 --port "$PORT" >"$R/sequencer-resumed.log" 2>&1
fi

# Reuse the verified #10 fixture, stopping before its first AMM journey.
# Program deploy, token setup, and AMM initialization are prerequisites only.
python3 - "$E/run-public-smoke-issue10.sh" "$W" <<'PY'
import pathlib, sys
source, work = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
script, marker, _ = source.read_text().partition('\ntx pool-create ')
assert marker, 'The runbook changed'
for old, new in {
    'WALLET="$LEZ/target/release/wallet"': 'WALLET="$ROOT/bin/wallet"',
    'SEQ="$LEZ/target/release/sequencer_service"': 'SEQ="$ROOT/bin/sequencer_service"',
    'SPEL="$SPEL_REPO/target/release/spel"': 'SPEL="$ROOT/bin/spel"',
    'PDAS="$PROGRAMS/target/debug/examples/amm_pdas"': 'PDAS="$ROOT/bin/amm_pdas"',
    '    <<< "$(openssl rand -hex 24)" >/dev/null': (
        '    < <(openssl rand -hex 24 | tee "$ROOT/fixture-wallet-password") >/dev/null'
    ),
}.items():
    assert script.count(old) == 1
    script = script.replace(old, new)
extra = r'''
inspect trader-a-initial "$TOKEN_IDL" "$HOLD_A" TokenHolding
inspect trader-b-initial "$TOKEN_IDL" "$HOLD_B" TokenHolding
run rpc getAccount "[\"$POOL\"]" | tee "$RUN_DIR/initial-pool.json"
tail -n 1 "$RUN_DIR/initial-pool.json" | jq -e '.result.data == []' >/dev/null

jq -n --arg da "$DEF_A" --arg db "$DEF_B" --arg ha "$HOLD_A" --arg hb "$HOLD_B" \
    '[{symbol:"QAA",name:"QA Token A",definitionId:$da,holding:$ha,decimals:2},
      {symbol:"QAB",name:"QA Token B",definitionId:$db,holding:$hb,decimals:3}]' \
    >"$RUN_DIR/tokens.json"
printf '%s\n' '[]' >"$RUN_DIR/pools.json"
{
    printf 'export %s=%q\n' \
        LEE_WALLET_HOME_DIR "$LEE_WALLET_HOME_DIR" \
        AMM_PROGRAM_ID "$AMM" AMM_CONFIG_ID "$CONFIG" \
        TOKENS_CONFIG "$RUN_DIR/tokens.json" AMM_POOLS_CONFIG "$RUN_DIR/pools.json" \
        RISC0_DEV_MODE "$RISC0_DEV_MODE" RISC0_SERVER_PATH "$RISC0_SERVER_PATH"
} >"$ROOT/basecamp-runtime.env"
jq -n --arg fee "$FEE_PAYER" --arg token "$TOKEN" --arg amm "$AMM" --arg twap "$TWAP" \
    --arg config "$CONFIG" --arg pool "$POOL" --arg a "$HOLD_A" --arg b "$HOLD_B" \
    --arg av "$VAULT_A" --arg bv "$VAULT_B" --arg lp "$LP_DEF" --arg lock "$LP_LOCK" \
    --arg tick "$TICK" --arg fa "$FEE_A" \
    '{feePayer:$fee,tokenProgram:$token,ammProgram:$amm,twapProgram:$twap,config:$config,
      pool:$pool,holderA:$a,holderB:$b,vaultA:$av,vaultB:$bv,lpDef:$lp,lpLock:$lock,tick:$tick,feeA:$fa}' \
    >"$RUN_DIR/public-ids.json"
printf '%s\n' "$RUN_DIR" >"$ROOT/run-dir"
'''
(work / "fixture-generated.sh").write_text(script + '\n' + extra)
PY
bash "$W/fixture-generated.sh" "$W"
# Keep the sequencer in this systemd cgroup until explicitly stopped.
exec /usr/bin/tail -f "$(<"$W/run-dir")/sequencer.log" >/dev/null

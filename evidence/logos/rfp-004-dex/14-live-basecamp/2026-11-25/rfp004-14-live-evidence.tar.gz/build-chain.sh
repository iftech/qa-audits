#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
cd "$W"
exec >"$E/build-chain.log" 2>&1

export GITHUB_TOKEN=$(/usr/bin/gh auth token)
export HOME="$W/home" TMPDIR="$W/tmp" CARGO_HOME="$W/cargo" RUSTUP_HOME="$W/rustup"
export XDG_CACHE_HOME="$W/cache" XDG_STATE_HOME="$W/state" XDG_CONFIG_HOME="$W/config"
export PATH="$W/bin:$CARGO_HOME/bin:$HOME/.risc0/bin:/usr/local/bin:/usr/bin:/bin"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_RELEASE_STRIP=debuginfo
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_NET_GIT_FETCH_WITH_CLI=true CARGO_BUILD_JOBS=4
export GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
mkdir -p "$HOME" "$TMPDIR" "$W/bin" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$XDG_STATE_HOME"

guard() {
    while :; do
        avail=$(df -B1 --output=avail "$W" | tail -1)
        printf '%s %s\n' "$(date -Is)" "$avail" >>"$E/disk-samples.txt"
        if (( avail < 3500000000 )); then
            echo "Disk guard: ${avail} bytes remaining; stopping build service." >&2
            systemctl --user stop --no-block rfp004-ui-chain.service || kill -TERM "$1"
            return
        fi
        sleep 2
    done
}
guard "$$" &
guard_pid=$!
trap 'kill "$guard_pid" 2>/dev/null || true' EXIT

checkout() {
    local name=$1 repo=$2 rev=$3 sha=$4
    if ! git -C "$name" cat-file -e "$rev^{commit}" 2>/dev/null; then
        [[ -d "$name/.git" ]] || git init -q "$name"
        git -C "$name" fetch --depth 1 "https://github.com/$repo.git" "$rev"
    fi
    git -C "$name" -c advice.detachedHead=false switch --detach "$rev"
    [[ $(git -C "$name" rev-parse HEAD) == "$rev" ]]
    printf '%s %s\n' "$name" "$rev"
    printf '%s  %s\n' "$sha" "$name/Cargo.lock" | sha256sum -c
}
checkout lez-programs logos-blockchain/lez-programs 1cfaa5e3446a684e6e9b61cfb243038dae6465ea 79e97ac8ebbe7429bf1b0735437cc1b8dd6e16ab987ba7028e7a184553af3b98
checkout logos-execution-zone logos-blockchain/logos-execution-zone d8596eb734bf9c9ce801afb92df06098a2eb098a 945399f86eb6e669f900efde9aea2a039c982332dbc3dc3991b00f87e86c7459
checkout spel logos-co/spel c6f73ce21e4805f8430f03afdbdedf0b7e479a5e 5bab3fa6ff21e0cf86a7fd51a9048f06c7d499950875c98ef67168796c948a7e

if ! rustc +1.94.0 -V; then
    curl -fSL --retry 2 https://sh.rustup.rs -o "$W/rustup-init.sh"
    sh "$W/rustup-init.sh" -y --no-modify-path --profile minimal --default-toolchain 1.94.0
fi
rustc +1.94.0 -Vv
cargo +1.94.0 -V

if [[ ! -x "$HOME/.risc0/bin/rzup" ]]; then
    curl -fSL --retry 2 https://risczero.com/install -o "$W/risc0-init.sh"
    bash "$W/risc0-init.sh"
fi
for component in r0vm cargo-risczero; do
    rzup install "$component" 3.0.5
    rzup default "$component" 3.0.5
done
r0vm --version
cargo +1.94.0 risczero --version

zkr_sha=744b999f0a35b3c86753311c7efb2a0054be21727095cf105af6ee7d3f4d8849
export RECURSION_SRC_PATH="$W/$zkr_sha.zip"
if [[ ! -f "$RECURSION_SRC_PATH" ]]; then
    curl -fSL --retry 2 "https://artifacts.risczero.net/zkr/$zkr_sha.zip" -o "$RECURSION_SRC_PATH.tmp"
    mv "$RECURSION_SRC_PATH.tmp" "$RECURSION_SRC_PATH"
fi
printf '%s  %s\n' "$zkr_sha" "$RECURSION_SRC_PATH" | sha256sum -c

# Prefer system Nix binaries read-only; do not build/install in the shared store.
export PATH="/nix/store/r9941n32g4wyvggz2703dlplbdq8a6rd-cmake-4.1.2/bin:/nix/store/armsfbcsbzax7pnkim9cqgkx8n747n31-protobuf-34.1/bin:/nix/store/4my6a75b8p1w734w7crqfw69jw7xarla-pkg-config-0.29.2/bin:$PATH"
if [[ -f "$W/native-deps.env" ]]; then source "$W/native-deps.env"; fi
export CARGO_TARGET_DIR="$W/target"
cd "$W/logos-execution-zone"
echo "Building pinned standalone sequencer and wallet"
/usr/bin/time -v cargo +1.94.0 build --locked --release -p sequencer_service --features standalone -p wallet
install -m755 "$CARGO_TARGET_DIR/release/sequencer_service" "$W/bin/"
install -m755 "$CARGO_TARGET_DIR/release/wallet" "$W/bin/"
sha256sum "$W/bin/"{sequencer_service,wallet}
"$W/bin/sequencer_service" --version
"$W/bin/wallet" --version
df -B1 "$W"

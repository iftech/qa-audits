#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
MODE=${1:-journey}
exec >"$W/basecamp-$MODE.log" 2>&1
export HOME="$W/bc-home" XDG_DATA_HOME="$W/bc-data" XDG_CONFIG_HOME="$W/bc-config"
export XDG_STATE_HOME="$W/bc-state" XDG_CACHE_HOME="$W/bc-cache" XDG_RUNTIME_DIR="$W/bc-runtime"
export TMPDIR="$W/tmp" QT_QPA_PLATFORM=xcb QT_QUICK_BACKEND=software
mkdir -p "$HOME" "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_STATE_HOME" "$XDG_CACHE_HOME" \
    "$XDG_RUNTIME_DIR" "$W/bc-user"
if [[ $MODE == journey ]]; then
    # Refuse to open the journey surface without both exact-stack gates.
    test -s "$W/run-dir"
    test -s "$W/basecamp-runtime.env"
    source "$W/basecamp-runtime.env"
    for module in amm_ui amm_module lez_core; do
        compgen -G "$W/packages/logos-$module-module*.lgx" >/dev/null
    done
    curl -fsS --max-time 5 -H 'Content-Type: application/json' \
        --data '{"jsonrpc":"2.0","id":1,"method":"checkHealth","params":[]}' \
        http://127.0.0.1:3040 | jq -e 'has("result")'
fi
basecamp=/home/qa/basecamp-chat/result-portable/bin/LogosBasecamp
export AMM_DEBUG=1
: >"$W/basecamp-display"
Xvfb -screen 0 1440x900x24 -nolisten tcp -displayfd 3 3>"$W/basecamp-display" &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true' EXIT
for ((n=0;n<40;n++)); do
    if [[ -s "$W/basecamp-display" ]]; then break; fi
    kill -0 "$xpid"
    sleep .25
done
[[ -s "$W/basecamp-display" ]]
export DISPLAY=":$(<"$W/basecamp-display")"
printf '%s\n' "$(realpath "$basecamp")" "$DISPLAY"
"$basecamp" --user-dir "$W/bc-user"

#!/usr/bin/env bash
set -euo pipefail
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
if [[ ${1:-} != inside ]]; then
    exec sudo -n /bin/bash "$0" inside "$(readlink -f "$(command -v nix)")"
fi
NIX=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
exec > >(tee "$E/nix-locked-cache-seed.log") 2>&1
[[ $(systemctl is-active rfp004-ui-packages.service || true) != active ]]
cd "$W"
{
    for lock in lez-programs/Cargo.lock logos-execution-zone/Cargo.lock spel/Cargo.lock; do
        awk -F'"' '/^source = "git\+/ {print $2}' "$lock"
    done
    # Cargo logged the exact Gitlink and URL resolved from each locked checkout.
    awk '/Updating git submodule/ { submodule=$NF; gsub(/`/,"",submodule) }
         /Updating git repository/ { submodule="" }
         /\[new ref\].*refs\/commit\// && submodule!="" {
             for (i=1;i<=NF;i++) if ($i ~ /^refs\/commit\//) {
                 hash=$i; sub(/^refs\/commit\//,"",hash)
                 print "git+" submodule "?rev=" hash "#" hash; submodule=""
             }
         }' "$E/build-chain.log"
} | sort -u | while IFS= read -r entry; do
    rev=${entry##*#}
    url=${entry#git+}
    url=${url%%\?*}
    [[ $url == https://github.com/* && $rev =~ ^[0-9a-f]{40}$ ]]
    test "$(df -B1 --output=avail "$W" | tail -1)" -ge 3500000000
    key=$(printf %s "$url" | sha256sum | cut -d' ' -f1)
    key=$("$NIX" hash convert --hash-algo sha256 --from base16 --to nix32 "$key")
    dst="$W/nix-cache/nix/gitv3/$key"
    mkdir -p "$dst"
    if [[ ! -d $dst/objects ]]; then git init --bare --quiet "$dst"; fi
    if ! git --git-dir="$dst" cat-file -e "$rev^{commit}" 2>/dev/null; then
        source=$url
        for src in "$W/cargo/git/db/"* "$W/"{lez-programs,logos-execution-zone,spel}/.git; do
            if git -c safe.directory="$src" --git-dir="$src" cat-file -e "$rev^{commit}" 2>/dev/null; then
                source=$src
                break
            fi
        done
        printf 'Caching exact locked Git object from %s: %s\n' "$url" "$rev"
        timeout --kill-after=5 120s git --git-dir="$dst" fetch --no-tags --depth 1 \
            "$source" "$rev:refs/heads/rfp004-$rev"
    fi
    [[ $(git --git-dir="$dst" rev-parse "$rev^{commit}") == "$rev" ]]
done

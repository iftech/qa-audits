#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
B="$W/bin/sequencer_service"
L="$W/logos-execution-zone"
exec >"$E/pinned-loopback-probe.txt" 2>&1
date -Is
test -x "$B"
test "$(git -C "$L" rev-parse HEAD)" = d8596eb734bf9c9ce801afb92df06098a2eb098a
test -z "$(ss -ltnH 'sport = :3040')"
P=$(mktemp -d "$W/chain-probe.XXXXXX")
mkdir "$P/chain"
export RISC0_DEV_MODE=1
export HOME="$W/home"
export RISC0_SERVER_PATH="$W/cargo/bin/r0vm"
test "$("$RISC0_SERVER_PATH" --version)" = 'risc0-r0vm 3.0.5'
jq 'del(.gossip) | .metrics_address = null | .block_create_timeout = "2s"' \
    "$L/lez/sequencer/service/configs/debug/sequencer_config.json" >"$P/config.json"
sha256sum "$B" "$P/config.json"
"$B" --version
"$B" "$P/config.json" --home "$P/chain" --listen-address 127.0.0.1 --port 3040 \
    >"$P/sequencer.log" 2>&1 &
pid=$!
cleanup() {
    local rc=$?
    if (( rc != 0 )); then
        grep -iE 'error|panic|listen' "$P/sequencer.log" | tail -15 || true
    fi
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
}
trap cleanup EXIT
rpc() {
    curl -fsS --max-time 3 -H 'Content-Type: application/json' \
        --data "$(jq -nc --arg method "$1" '{jsonrpc:"2.0",id:1,method:$method,params:[]}')" \
        http://127.0.0.1:3040
}
for ((n=0;n<50;n++)); do
    if rpc checkHealth 2>/dev/null | jq -e 'has("result")' >/dev/null; then break; fi
    kill -0 "$pid"
    sleep 1
done
listen=$(ss -ltnH 'sport = :3040')
printf '%s\n' "$listen"
[[ $(awk '{print $4}' <<<"$listen") == 127.0.0.1:3040 ]]
health=$(rpc checkHealth)
printf '%s\n' "$health"
jq -e 'has("result")' <<<"$health" >/dev/null
rpc getChannelId
printf '\n'
date -Is

#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
exec >"$E/build-guests.log" 2>&1
cd "$W/lez-programs"
test "$(git rev-parse HEAD)" = 1cfaa5e3446a684e6e9b61cfb243038dae6465ea
image=sha256:3e12f71bacd27527a61dea96fa0e53e468c99aa261d3a1019b593f6dbd943eb3
test -x "$W/bin/spel"
export DOCKER_HOST="unix://$W/dockerd.sock"
export DOCKER_CONFIG="$W/docker-cli" TMPDIR="$W/tmp" HOME="$W/home"
mkdir -p "$DOCKER_CONFIG"
printf '%s\n' '{}' >"$W/dockerd-config.json"
sudo -n systemd-run --unit rfp004-ui-guest-docker \
    -p KillMode=control-group -p RuntimeMaxSec=45m -p Nice=10 \
    /usr/bin/dockerd --config-file "$W/dockerd-config.json" --host "$DOCKER_HOST" \
    --data-root "$W/docker-data" --exec-root "$W/docker-exec" --pidfile "$W/dockerd.pid" \
    --group "$(id -gn)" --storage-driver overlay2 --feature containerd-snapshotter=false \
    --bridge none --iptables=false --ip6tables=false --ip-forward=false --ip-masq=false --userland-proxy=false
cleanup() {
    sudo -n systemctl stop rfp004-ui-guest-docker.service || true
    kill "${guard_pid:-0}" 2>/dev/null || true
}
guard() {
    while :; do
        available=$(df -B1 --output=avail "$W" | tail -1)
        printf '%s %s\n' "$(date -Is)" "$available" >>"$E/guest-disk.txt"
        if (( available < 3500000000 )); then
            echo "Disk guard: $available bytes free; stopping."
            sudo -n systemctl stop --no-block rfp004-ui-guest-docker.service
            return
        fi
        sleep 2
    done
}
guard &
guard_pid=$!
trap cleanup EXIT
for ((n=0;n<30;n++)); do
    if docker version --format '{{.Server.Version}}' 2>/dev/null; then break; fi
    sleep 1
done
docker info --format 'Storage: {{.Driver}} at {{.DockerRootDir}}'
export RISC0_DOCKER_CONTAINER_TAG="r0.1.88.0@$image"
export RISC0_DOCKER_BUILD_NETWORK=host
export RISC0_BUILD_CACHE_ID=rfp004-ui-20261125-112205
docker buildx imagetools inspect "risczero/risc0-guest-builder:$RISC0_DOCKER_CONTAINER_TAG"
scripts/build-guests.sh token twap_oracle amm
sha256sum target/guest/{token,twap_oracle,amm}.bin
test "$("$W/bin/spel" program-id target/guest/token.bin --format hex)" = 057e9cc28c7bd70645f74fa2c38e9880e532d369bda31a4bbaa24f5f1e93a6bc
test "$("$W/bin/spel" program-id target/guest/twap_oracle.bin --format hex)" = 979279c5fa38173abf0d35370e2c481303ec28f959c7eeb98ab74a7e90ce3edd
test "$("$W/bin/spel" program-id target/guest/amm.bin --format hex)" = a69de4104f829dadb356f05f46ea1d79fc819618f2ebedb341d5b2e041d8bd79
printf '%s\n' 'All three guest ImageIDs match issue #10.'

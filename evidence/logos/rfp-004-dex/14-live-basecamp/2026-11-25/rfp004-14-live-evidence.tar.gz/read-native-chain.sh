#!/usr/bin/env bash
set -euo pipefail
umask 077
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
PHASE=${1:?usage: read-native-chain.sh phase [tx-hash] [additional-account...]}
[[ $PHASE =~ ^[a-zA-Z0-9.-]+$ ]]
TX=${2:-}
if [[ -n $TX ]]; then [[ $TX =~ ^[0-9a-f]{64}$ ]]; fi
R=$(<"$W/run-dir")
IDS="$R/public-ids.json"
OUT="$E/readback/$PHASE"
test -s "$IDS"
mkdir -p "$OUT"

rpc() {
    local method=$1 params=${2:-'[]'}
    curl -fsS --max-time 6 -H 'Content-Type: application/json' \
        --data "$(jq -nc --arg method "$method" --argjson params "$params" \
          '{jsonrpc:"2.0",id:1,method:$method,params:$params}')" \
        'http://127.0.0.1:3040'
}
date -Is | tee "$OUT/timestamp.txt"
rpc checkHealth | tee "$OUT/health.json" | jq -e 'has("result")' >/dev/null
rpc getChannelId >"$OUT/channel.json"
rpc getLastBlockId >"$OUT/last-block.json"
cd "$W/lez-programs"
source "$W/basecamp-runtime.env"
if [[ -n $TX ]]; then
    rpc getTransaction "[\"$TX\"]" | tee "$OUT/transaction.json"
fi
for pair in config:AmmConfig pool:PoolDefinition holderA:TokenHolding holderB:TokenHolding \
    vaultA:TokenHolding vaultB:TokenHolding lpDef:TokenDefinition \
    lpLock:TokenHolding feeA:TokenHolding tick:CurrentTickAccount feePayer:raw; do
    field=${pair%:*}
    kind=${pair#*:}
    id=$(jq -er --arg field "$field" '.[$field]' "$IDS")
    rpc getAccount "[\"$id\"]" >"$OUT/$field.raw.json"
    if [[ $kind != raw ]] && jq -e '.result.data | length > 0' "$OUT/$field.raw.json" >/dev/null; then
        idl=token
        case $kind in
            AmmConfig|PoolDefinition) idl=amm ;;
            CurrentTickAccount) idl=twap_oracle ;;
        esac
        "$W/bin/spel" --idl "artifacts/$idl-idl.json" inspect "$id" --type "$kind" \
            >"$OUT/$field.decoded.json"
    fi
done
if (( $# > 2 )); then
    shift 2
    for id; do
        [[ $id =~ ^[1-9A-HJ-NP-Za-km-z]{32,44}$ ]]
        rpc getAccount "[\"$id\"]" >"$OUT/$id.raw.json"
        if jq -e '.result.data | length > 0' "$OUT/$id.raw.json" >/dev/null; then
            "$W/bin/spel" --idl artifacts/token-idl.json inspect "$id" --type TokenHolding \
                >"$OUT/$id.decoded.json"
        fi
    done
fi

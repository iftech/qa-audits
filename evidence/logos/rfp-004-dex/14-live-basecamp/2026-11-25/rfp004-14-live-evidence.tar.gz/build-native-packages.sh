#!/usr/bin/env bash
set -euo pipefail
umask 022
E=$(dirname "$(realpath "$0")")
W=${E%-evidence}
if [[ ${1:-} != inside ]]; then
    exec sudo -n unshare -m --propagation private /bin/bash "$0" inside \
        "$(readlink -f "$(command -v nix)")" "${PACKAGE_MODE:-build}" "${NIX_BUILD_TMPFS:-}"
fi
NIX=$2
MODE=$3
RAM_SCRATCH=${4:-}
exec > >(tee "$E/native-packages-$MODE.log") 2>&1
date -Is
df -B1 "$W"

mkdir -p "$W/nix-upper" "$W/nix-work" "$W/nix-merged/nix/store" \
    "$W/nix-sources" "$W/nix-home" "$W/nix-cache" "$W/nix-state" "$W/nix-tmp" "$W/packages"
# Sandboxed nixbld users cannot traverse /home/qa. Bind only this run's
# scratch at /mnt in this private namespace; no host mounts or ACL changes.
mount --bind "$W" /mnt
S=/mnt
mount -t overlay overlay -o "lowerdir=/nix/store,upperdir=$S/nix-upper,workdir=$S/nix-work" \
    "$S/nix-merged/nix/store"
export HOME="$W/nix-home" TMPDIR="$S/nix-tmp"
export XDG_CONFIG_HOME="$W/nix-home" XDG_CACHE_HOME="$W/nix-cache" XDG_STATE_HOME="$W/nix-state"
export GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
export PATH="$(dirname "$NIX"):/usr/local/bin:/usr/bin:/bin"
build_dir_args=()
if [[ -n $RAM_SCRATCH ]]; then
    [[ $RAM_SCRATCH =~ ^[1-6]G$ ]]
    mount -t tmpfs -o "size=$RAM_SCRATCH,mode=0755,nosuid,nodev" tmpfs "$S/nix-tmp"
    build_dir_args=(--option build-dir "$S/nix-tmp")
    printf 'Nix temporary build directory: private tmpfs, capped at %s\n' "$RAM_SCRATCH"
fi

guard() {
    while :; do
        available=$(df -B1 --output=avail "$W" | tail -1)
        printf '%s %s\n' "$(date -Is)" "$available" >>"$E/native-packages-disk.txt"
        if (( available < 3500000000 )); then
            echo "Disk guard: $available bytes free; stopping."
            systemctl stop --no-block rfp004-ui-packages.service || kill -TERM "$1"
            return
        fi
        if [[ -n $RAM_SCRATCH ]]; then
            mem_available=$(awk '$1=="MemAvailable:" {print $2}' /proc/meminfo)
            if (( mem_available < 1600000 )); then
                echo "Memory guard: $mem_available KiB available; stopping."
                systemctl stop --no-block rfp004-ui-packages.service || kill -TERM "$1"
                return
            fi
        fi
        sleep 2
    done
}
guard "$$" &
guard_pid=$!
trap 'kill "$guard_pid" 2>/dev/null || true' EXIT

cd "$W/lez-programs"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="$PWD"
pin=$(git -c safe.directory="$PWD" rev-parse HEAD)
[[ $pin = 1cfaa5e3446a684e6e9b61cfb243038dae6465ea ]]
[[ -z $(git -c safe.directory="$PWD" status --porcelain --untracked-files=no) ]]
printf 'Audited source: %s\n' "$pin"
sha256sum flake.lock
logos_cache_key=$(sed -n 's/^ *"\(logos-co\.cachix\.org-1:[^"]*\)"$/\1/p' flake.nix)
[[ -n $logos_cache_key && $logos_cache_key != *$'\n'* ]]

# The archived Git tree is identical to the locked NAR. Change only the
# transport in a separate lock file; the checked-out tree stays untouched.
rev=e013376c32a8fcf07ddb6ec71739552bc118b7bd
tarball="$W/nix-sources/rust-overlay.tar.gz"
tree="$W/nix-sources/rust-overlay"
locked_nar=$(jq -er --arg rev "$rev" '.nodes[].locked | select(.rev == $rev).narHash' flake.lock | sort -u)
if [[ ! -s $tarball ]]; then
    curl -fSL --max-time 120 --retry 1 "https://codeload.github.com/oxalica/rust-overlay/tar.gz/$rev" -o "$tarball.tmp"
    mv "$tarball.tmp" "$tarball"
fi
if [[ ! -f $tree/flake.nix ]]; then
    mkdir -p "$tree"
    tar -xzf "$tarball" -C "$tree" --strip-components=1
fi
actual_nar=$("$NIX" hash path "$tree")
[[ $actual_nar = "$locked_nar" ]]
printf 'rust-overlay %s (codeload): %s, matches immutable lock\n' "$rev" "$actual_nar"
jq --arg rev "$rev" --arg url "file://$tarball" \
    '(.nodes[] | select(.locked.rev == $rev) | .locked) |= (del(.owner,.repo,.rev) + {type:"tarball",url:$url})' \
    flake.lock >"$W/nix-sources/alternate-flake.lock"

common=(
    --extra-experimental-features "nix-command flakes local-overlay-store"
    --store "local-overlay://?root=$S/nix-merged&lower-store=daemon&upper-layer=$S/nix-upper"
    --no-write-lock-file --accept-flake-config
    --option max-jobs 1 --option cores 4
    --option connect-timeout 10 --option download-attempts 2
    --option extra-substituters ""
    --option substituters "https://cache.nixos.org https://logos-co.cachix.org"
    --option extra-trusted-public-keys "$logos_cache_key"
    "${build_dir_args[@]}"
)
# Access the *transitively locked* wallet package, not a second independently
# resolved flake. Nix CLI installs only exposed top-level attributes, and
# getFlake ignores --reference-lock-file when invoked from an expression.
# The scratch archive contains the exact tracked tree and a transport-only
# alternate lock. Never modify the checked-out Git tree.
snapshot="$W/nix-sources/pinned-tree"
mkdir -p "$snapshot"
if [[ ! -f "$snapshot/flake.nix" ]]; then
    git -c safe.directory="$PWD" archive "$pin" | tar -x -C "$snapshot"
fi
cp "$W/nix-sources/alternate-flake.lock" "$snapshot/flake.lock"
expr="let f = builtins.getFlake \"path:$snapshot\"; p = f.packages.x86_64-linux; in [
       p.amm-ui-lgx-portable
       p.amm-module-lgx-portable
       f.inputs.lez_core.packages.x86_64-linux.lgx-portable
     ]"
pkg=(--impure --expr "$expr")
if [[ $MODE == plan ]]; then
    "$NIX" build "${common[@]}" --no-link --dry-run "${pkg[@]}"
elif [[ $MODE == serial || $MODE == amm_ui || $MODE == amm_module || $MODE == lez_core ]]; then
    for item in \
        'amm_ui:p.amm-ui-lgx-portable' \
        'amm_module:p.amm-module-lgx-portable' \
        'lez_core:f.inputs.lez_core.packages.x86_64-linux.lgx-portable'; do
        component=${item%%:*}
        attr=${item#*:}
        [[ $MODE == serial || $MODE == "$component" ]] || continue
        if compgen -G "$W/packages/logos-$component-module*.lgx" >/dev/null; then
            printf 'Already preserved: %s\n' "$component"
            sha256sum "$W/packages/logos-$component-module"*.lgx
            continue
        fi
        printf 'Building isolated component: %s\n' "$component"
        "$NIX" build "${common[@]}" --no-link --print-out-paths \
            --impure --expr "let f = builtins.getFlake \"path:$snapshot\"; p = f.packages.x86_64-linux; in $attr" \
            | tee "$E/native-package-$component-out-path.txt"
        while IFS= read -r path; do
            find "$S/nix-merged$path" -type f -name '*.lgx' -exec cp -v {} "$W/packages/" \;
        done <"$E/native-package-$component-out-path.txt"
        sha256sum "$W/packages/logos-$component-module"*.lgx
        df -B1 "$W"
    done
else
    "$NIX" build "${common[@]}" --no-link --print-out-paths "${pkg[@]}" | tee "$E/native-package-out-paths.txt"
    while IFS= read -r path; do
        find "$S/nix-merged$path" -type f -name '*.lgx' -exec cp -v {} "$W/packages/" \;
    done <"$E/native-package-out-paths.txt"
    sha256sum "$W/packages/"*.lgx
    df -B1 "$W"
fi

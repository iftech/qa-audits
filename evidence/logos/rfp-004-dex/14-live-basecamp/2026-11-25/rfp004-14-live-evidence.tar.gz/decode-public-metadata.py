"""Summarize the signed public transaction stored by this LEZ fixture."""
import base64
import json
import sys


def b58(buf):
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    n, text = int.from_bytes(buf, "big"), ""
    while n:
        n, digit = divmod(n, 58)
        text = alphabet[digit] + text
    return "1" * (len(buf) - len(buf.lstrip(b"\0"))) + text


with open(sys.argv[1]) as fh:
    signed, block = json.load(fh)["result"]
with open(sys.argv[2]) as fh:
    known = json.load(fh)
raw = base64.b64decode(signed)
read_int = lambda b: int.from_bytes(b, "little")
count = read_int(raw[33:37])
accounts = [b58(raw[37 + i * 32:69 + i * 32]) for i in range(count)]
assert accounts[1] == known["pool"]
ops = {"create": (1, 4, 8), "add": (1, 4, 7), "remove": (1, 4, 7)}
op = sys.argv[3]
if op in ops:
    pool_index, definition_index, holding_index = ops[op]
    assert accounts[pool_index] == known["pool"]
    assert accounts[definition_index] == known["lpDef"]
    print(json.dumps({"block": block, "lpHolding": accounts[holding_index]}))
elif op == "swap":
    # The fixture's signed public tx prefixes the instruction with the
    # account list and 16-byte nonces of all signing accounts.
    # Resolve the unique (length=41, AMM discriminator) vector before
    # asserting the independently provided amount and bound below.
    start = 37 + count * 32
    candidates = [
        i for i in range(start, start + 64)
        if raw[i:i + 4] == b"\x29\x00\x00\x00" and raw[i + 4] in (7, 8)
    ]
    assert len(candidates) == 1, candidates
    i = candidates[0] + 4
    amount, limit = read_int(raw[i+1:i+17]), read_int(raw[i+17:i+33])
    assert (amount, limit) == (int(sys.argv[4]), int(sys.argv[5]))
    print(json.dumps({"block": block, "discriminator": raw[i],
                      "amount": amount, "bound": limit}))
